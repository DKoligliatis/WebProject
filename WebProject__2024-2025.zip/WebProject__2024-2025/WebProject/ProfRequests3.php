<?php
require 'config.php'; // Database connection
session_start();

$profID = $_SESSION['userID']; // Get the logged-in professor's ID

// Handle AJAX requests
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'];

    if ($action === 'respondToInvitation') {
        $committeeID = $_POST['committeeID'];
        $response = $_POST['response'];

        try {
            // Call the procedure
            $stmt = $conn->prepare("CALL respondToInvitation(?, ?, ?)");
            $stmt->bind_param("iis", $profID, $committeeID, $response);
            $stmt->execute();
            echo json_encode(['success' => true, 'message' => 'Η απάντησή σας καταχωρήθηκε επιτυχώς.']);
        } catch (Exception $e) {
            echo json_encode(['success' => false, 'message' => 'Σφάλμα: ' . $e->getMessage()]);
        }
        exit();
    }
}

// Fetch pending invitations
try {
    $sql = "SELECT 
                u.firstName AS studentFirstName,
                u.lastName AS studentLastName,
                t.title AS topicTitle,
                r.dateOfReq AS requestDate,
                r.commiteeReqID AS committeeID
            FROM 
                reqList r
            JOIN 
                professors p ON r.profID = p.profID
            JOIN 
                committees c ON r.commiteeReqID = c.committeeID
            JOIN 
                diplomas d ON c.committeeID = d.committeeID
            JOIN 
                undergraduates ug ON d.studentID = ug.studentID
            JOIN 
                users u ON ug.studentID = u.userID
            JOIN 
                topics t ON c.topicID = t.topicID
            WHERE 
                p.profID = ?";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $profID);
    $stmt->execute();
    $result = $stmt->get_result();
    $requests = $result->fetch_all(MYSQLI_ASSOC);

} catch (Exception $e) {
    die("Error: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ανάθεση Θέματος</title>
    <link rel="stylesheet" href="ProfManageThesisPage.css">
</head>
<body>
    <div class="container">
        <!-- Άνω τμήμα της σελίδας με το λογότυπο και το κουμπί εξόδου -->
        <div class="upper-section">
			<!-- Σύνδεσμος για να επιστρέψει ο χρήστης στην ιστοσελίδα του τμήματος -->
			<a href="https://www.ceid.upatras.gr" target="_self">
				<!-- Εικόνα του λογότυπου του τμήματος -->
				<img src="upatras_ceid_logo.png" alt="upatras_ceid_logo">
			</a>

			<!-- Κουμπί εξόδου για αποσύνδεση από την πλατφόρμα -->
			<button class="logout-button"onclick="window.location.href='logout.php'">Έξοδος</button>
		</div>

        <!-- Κουμπί για την αλλαγή γλώσσας της σελίδας -->
        <div class="language-toggle">
            <button id="languageButton">
                <!-- Εικονίδιο που δείχνει την επιλογή γλώσσας -->
                <img src="language.png" alt="languageIcon">
            </button>
        </div>
		
        <!-- Κύριο περιεχόμενο της σελίδας -->
        <div class="container">  
            <div class="main-menu">   
                <!-- Κουμπί για το προφίλ του καθηγητή -->
                <button class="menu-item" id="profile">Προφίλ </button>
                
                <!-- Κουμπί για την προβολή και δημιουργία θεμάτων προς ανάθεση -->
                <button class="menu-item" id="view-and-create-thesis">Προβολή και Δημιουργία <br>Θεμάτων προς Ανάθεση</button>  
                
                <!-- Κουμπί για την αρχική ανάθεση θέματος σε φοιτητή -->
                <button class="menu-item" id="assign-thesis">Αρχική Ανάθεση Θέματος <br>σε Φοιτητή </button>  
                
                <!-- Κουμπί για την προβολή λίστας διπλωματικών εργασιών -->
                <button class="menu-item" id="view-list-thesis">Προβολή Λίστας <br>Διπλωματικών</button>

                <button class="menu-item" id="view-requests-3">Προβολή Προσκλήσεων <br> Συμμετοχής σε Τριμελή</button>
                
                <!-- Κουμπί για την προβολή στατιστικών -->
                <button class="menu-item" id="view-sattistics">Προβολή Στατιστικών</button>
                
                <!-- Κουμπί για τη διαχείριση των διπλωματικών εργασιών -->
                <button class="menu-item" id="manage-thesis">Διαχείριση Διπλωματικών <br>Εργασιών</button>
            </div>  

    <div class="content">
        <h1>Αιτήσεις για Επιτροπή</h1>
        <?php if (count($requests) > 0): ?>
            <h3>Συνολικός Αριθμός Αιτήσεων: <?php echo count($requests); ?></h3>
            <table>
                <thead>
                    <tr>
                        <th>Φοιτητής</th>
                        <th>Θέμα</th>
                        <th>Ημερομηνία Αίτησης</th>
                        <th>Ενέργειες</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($requests as $request): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($request['studentFirstName'] . ' ' . $request['studentLastName']); ?></td>
                        <td><?php echo htmlspecialchars($request['topicTitle']); ?></td>
                        <td><?php echo htmlspecialchars($request['requestDate']); ?></td>
                        <td>
                            <button class="accept-btn" onclick="respondToInvitation(<?php echo $request['committeeID']; ?>, 'Accept')">Αποδοχή</button>
                            <button class="decline-btn" onclick="respondToInvitation(<?php echo $request['committeeID']; ?>, 'Decline')">Απόρριψη</button>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p>Δεν υπάρχουν αιτήσεις για έγκριση.</p>
        <?php endif; ?>
    </div>

    <script>
        function respondToInvitation(committeeID, response) {
            if (!confirm(`Είστε σίγουροι ότι θέλετε να ${response === 'Accept' ? 'αποδεχτείτε' : 'απορρίψετε'} την αίτηση;`)) {
                return;
            }

            fetch('', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: `action=respondToInvitation&committeeID=${committeeID}&response=${response}`
            })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        alert(data.message);
                        location.reload(); // Ανανεώνει τη σελίδα για να ενημερωθεί η λίστα
                    } else {
                        alert('Σφάλμα: ' + data.message);
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    alert('Παρουσιάστηκε πρόβλημα κατά την επεξεργασία της αίτησης.');
                });
        }
    </script>
    <script src="LogoutButton.js"></script>    
    <script src="ProfessorProfileButton.js"></script>
    <script src="ProfViewCreateThesisPageButton.js"></script>
    <script src="ProfAssignThesisPageButton.js"></script>
    <script src="ProfViewListThesisPageButton.js"></script>
    <script src="ProfManageThesisPageButton.js"></script>
    <script src="ProfRequests3.js"></script>
    <script src="ProfStatistics.js"></script>
</body>
</html>
