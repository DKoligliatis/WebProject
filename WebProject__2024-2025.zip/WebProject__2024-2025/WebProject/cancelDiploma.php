<?php
require 'config.php';
session_start();

// Παίρνουμε τα δεδομένα από τη φόρμα
$topicID = $_POST['topicID'];
$cancelReason = $_POST['cancelReason'];
$assemblyYear = $_POST['assemblyYear'];
$assemblyNumber = $_POST['assemblyNumber'];

// Ενημερώνουμε την κατάσταση του diploma σε "Cancelled" και τα άλλα πεδία
$sql = "UPDATE diplomas 
        SET status = 'Cancelled', 
            assemblyYear = ?, 
            assemblyNumber = ?, 
            cancelReason = ? 
        WHERE topicID = ?";

$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "ssssi", $assemblyYear, $assemblyNumber, $cancelReason, $topicID);

// Εκτελούμε το query
if (mysqli_stmt_execute($stmt)) {
    echo "Η διπλωματική εργασία ακυρώθηκε με επιτυχία!";
} else {
    echo "Σφάλμα κατά την ακύρωση της διπλωματικής εργασίας.";
}

mysqli_stmt_close($stmt);
mysqli_close($conn);
?>