<?php
require 'config.php'; // Σύνδεση με βάση δεδομένων
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_FILES['jsonFile'])) {
        $file = $_FILES['jsonFile']['tmp_name']; // Λήψη του αρχείου JSON

        // Ανάγνωση περιεχομένου JSON αρχείου
        $jsonContent = file_get_contents($file);
        $data = json_decode($jsonContent, true);

        // Έλεγχος εγκυρότητας JSON και ύπαρξης δεδομένων
        if ($data === null || (!isset($data['students']) && !isset($data['professors']))) {
            die(json_encode(['success' => false, 'message' => 'Μη έγκυρο αρχείο JSON.']));
        }

        $conn->begin_transaction(); // Έναρξη συναλλαγής

        try {
            // Εισαγωγή φοιτητών, αν υπάρχουν
            if (isset($data['students'])) {
                foreach ($data['students'] as $student) {
                    $firstName = $student['name'];
                    $lastName = $student['surname'];
                    $email = $student['email'];
                    $AM = $student['student_number'];
                    $address = $student['street'] . ' ' . $student['number'] . ', ' . $student['city'] . ' ' . $student['postcode'];
                    $phoneMobile = $student['mobile_telephone'];
                    $phoneHome = $student['landline_telephone'];

                    // Εισαγωγή στον πίνακα `users`
                    $stmt = $conn->prepare("INSERT INTO users (userType, firstName, lastName, password, acEmail) VALUES ('undergraduate', ?, ?, '', ?)");
                    $stmt->bind_param("sss", $firstName, $lastName, $email);
                    $stmt->execute();
                    $userID = $stmt->insert_id;

                    // Εισαγωγή στον πίνακα `undergraduates`
                    $stmt = $conn->prepare("INSERT INTO undergraduates (studentID, AM, address, phone_mobile, phone_home) VALUES (?, ?, ?, ?, ?)");
                    $stmt->bind_param("issss", $userID, $AM, $address, $phoneMobile, $phoneHome);
                    $stmt->execute();
                }
            }

            // Εισαγωγή καθηγητών, αν υπάρχουν
            if (isset($data['professors'])) {
                foreach ($data['professors'] as $professor) {
                    $firstName = $professor['name'];
                    $lastName = $professor['surname'];
                    $email = $professor['email'];
                    $title = $professor['topic']; 

                    // Εισαγωγή στον πίνακα `users`
                    $stmt = $conn->prepare("INSERT INTO users (userType, firstName, lastName, password, acEmail) VALUES ('professor', ?, ?, '', ?)");
                    $stmt->bind_param("sss", $firstName, $lastName, $email);
                    $stmt->execute();
                    $userID = $stmt->insert_id;

                    // Εισαγωγή στον πίνακα `professors`
                    $stmt = $conn->prepare("INSERT INTO professors (profID, profTitle) VALUES (?, ?)");
                    $stmt->bind_param("is", $userID, $title);
                    $stmt->execute();
                }
            }

            $conn->commit(); // Επιβεβαίωση όλων των εισαγωγών
            echo json_encode(['success' => true, 'message' => 'Τα δεδομένα εισήχθησαν επιτυχώς.']);
        } catch (Exception $e) {
            $conn->rollback(); // Ακύρωση όλων των αλλαγών
            echo json_encode(['success' => false, 'message' => 'Σφάλμα: ' . $e->getMessage()]);
        }
    } else {
        echo json_encode(['success' => false, 'message' => 'Δεν βρέθηκε αρχείο.']);
    }
    exit();
}
?>

<!DOCTYPE html>
<html lang="el">

<head>
        <!-- Τίτλος της σελίδας που εμφανίζεται στην καρτέλα -->
        <title>ΤΜΥΠ | Εισαγωγή Δεδομένων Φοιτητών και Καθηγητών</title>
        
        <!-- Ορισμός της εικόνας που εμφανίζεται στην καρτέλα -->
        <link rel="icon" type="image/png" href="ceid_logo.png">
        
        <!-- Σύνδεση με το αρχείο CSS για την εμφάνιση της σελίδας -->
        <link rel="stylesheet" href="SecretaryInsertDataPage.css">
        
    </head>

    <body>
        <!-- Άνω τμήμα της σελίδας με το λογότυπο και το κουμπί εξόδου -->
        <div class="upper-section">
			<!-- Σύνδεσμος για να επιστρέψει ο χρήστης στην ιστοσελίδα του τμήματος -->
			<a href="https://www.ceid.upatras.gr" target="_self">
				<!-- Εικόνα του λογότυπου του τμήματος -->
				<img src="upatras_ceid_logo.png" alt="upatras_ceid_logo">
			</a>

			<!-- Κουμπί εξόδου για αποσύνδεση από την πλατφόρμα -->
			<button class="logout-button"onclick="window.location.href='logout.php'">Έξοδος</button>
		</div>

        <!-- Κουμπί για την αλλαγή γλώσσας της σελίδας -->
        <div class="language-toggle">
            <button id="languageButton">
                <!-- Εικονίδιο που δείχνει την επιλογή γλώσσας -->
                <img src="language.png" alt="languageIcon">
            </button>
        </div>
		
        <!-- Κύριο περιεχόμενο της σελίδας -->
        <div class="container">  
            <div class="main-menu">   
                <!-- Κουμπί για το προφίλ της γραμματείας -->
                <button class="menu-item" id="profile">Προφίλ </button>
                
                <!-- Κουμπί για την προβολή των διπλωματικών εργασιών -->
                <button class="menu-item" id="view-thesis">Προβολή Διπλωματικών <br>Εργασιών</button>  
                
                <!-- Κουμπί για την εισαγωγή δεδομένων για τις διπλωματικές εργασίες -->
                <button class="menu-item" id="data-input">Εισαγωγή Δεδομένων </button>  
              
            </div> 

    <div class="content">
        <h1>Εισαγωγή Δεδομένων Φοιτητών και Καθηγητών</h1>
        <form id="json-upload-form" enctype="multipart/form-data">
            <label for="jsonFile"><h3>Επιλέξτε αρχείο JSON:</h3></label>
            <input type="file" id="jsonFile" name="jsonFile" accept=".json" required>
            <button type="submit" id="submit">Εισαγωγή</button>
        </form>

        <p id="response-message"></p>
    </div>

    <script>
        document.getElementById('json-upload-form').addEventListener('submit', function (event) {
            event.preventDefault(); // Ακύρωση της τυπικής υποβολής

            const formData = new FormData(this); // Δημιουργία FormData από τη φόρμα

            fetch('SecretaryInsertData.php', {
                method: 'POST',
                body: formData
            })
                .then(response => response.json())
                .then(data => {
                    const responseMessage = document.getElementById('response-message');
                    if (data.success) {
                        responseMessage.textContent = data.message;
                        responseMessage.style.color = 'green';
                    } else {
                        responseMessage.textContent = data.message;
                        responseMessage.style.color = 'red';
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    const responseMessage = document.getElementById('response-message');
                    responseMessage.textContent = 'Σφάλμα κατά την αποστολή του αρχείου.';
                    responseMessage.style.color = 'red';
                });
        });
    </script>
     <script src="LogoutButton.js"></script>
    <script src="SecretaryProfileButton.js"></script>
    <script src="SecretaryViewThesisPageButton.js"></script>
    <script src="SecretaryInsertDataPageButton.js"></script>
</body>
</html>
