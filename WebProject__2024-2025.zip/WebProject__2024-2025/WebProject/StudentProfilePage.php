<?php
session_start();
 
// Ανάκτηση δεδομένων χρήστη από τη συνεδρία
$userID = htmlspecialchars($_SESSION['userID']);
$firstName = htmlspecialchars($_SESSION['firstName']);
$lastName = htmlspecialchars($_SESSION['lastName']);
$email = htmlspecialchars($_SESSION['acEmail']);
$address = htmlspecialchars($_SESSION['address']);
$phoneMobile = htmlspecialchars($_SESSION['phone_mobile']);
$phoneHome = htmlspecialchars($_SESSION['phone_home']);
$AM = htmlspecialchars($_SESSION['AM']);
?>

<!DOCTYPE html>
<html>
    <head>
        <!-- Τίτλος της σελίδας που εμφανίζεται στην καρτέλα -->
        <title>ΤΜΥΠ | Το προφίλ μου</title> 
        <!-- Εικονίδιο της σελίδας -->
        <link rel="icon" type="image/png" href="ceid_logo.png"> 
        <!-- Σύνδεση με το αρχείο CSS για την εμφάνιση της σελίδας -->
        <link rel="stylesheet" href="StudentProfilePage.css"> 
    </head>
    <body>
        <div class="upper-section">
            <!-- Σύνδεσμος στην ιστοσελίδα του τμήματος -->
            <a href="https://www.ceid.upatras.gr" target="_self"> 
                <!-- Λογότυπο του τμήματος -->
                <img src="upatras_ceid_logo.png" alt="upatras_ceid_logo"> 
            </a>
            <!-- Κουμπί αποσύνδεσης που ανακατευθύνει στη σελίδα MainPage.html -->
            <button class="logout-button" id="logout-button" onclick="window.location.href='Logout.php'">Έξοδος</button>
        </div>

        <div class="container">
            <div class="main-menu">
                <!-- Κουμπί προβολής προφίλ -->
                <button class="menu-item" id="profile">Προφίλ</button> 
                <button class="menu-item" id="view-thesis">Προβολή Θέματος <br> Διπλωματικής Εργασίας</button>
                <!-- Κουμπί προβολής θέματος διπλωματικής -->
                <button class="menu-item" id="manage-thesis">Διαχείριση Διπλωματικής <br> Εργασίας</button>
            </div> 
            <div class="content">
                <div class="profile-container">
                    <div class="profile-header">
                        <img class="profile-picture" src="face.jpg" alt="Profile Picture"> <!-- Εικόνα προφίλ -->
                        <div class="profile-info">
                            <h1><?php echo $firstName . ' ' . $lastName; ?></h1> <!-- Εμφάνιση ονοματεπωνύμου -->
                            <p>up1093392</p> 
                        </div>
                        <button class="edit-button" id="edit-buttonSt">Αλλαγή</button> <!-- Κουμπί επεξεργασίας στοιχείων -->
                        
                    </div>
                    <div class="profile-details">
                        <h2>Προσωπικά Στοιχεία</h2> <!-- Τίτλος ενότητας -->
                        <p><strong>E-mail:</strong> <?php echo $email; ?></p> <!-- Εμφάνιση email -->
                        <p><strong>Αριθμός μητρώου:</strong> <?php echo $AM; ?></p> <!-- Εμφάνιση αριθμού μητρώου -->
                        <p><strong>Κινητό Τηλέφωνο:</strong> <?php echo $phoneMobile; ?></p> <!-- Εμφάνιση κινητού τηλεφώνου -->
                        <p><strong>Σταθερό Τηλέφωνο:</strong><?php echo $phoneHome; ?></p> <!-- Εμφάνιση σταθερού τηλεφώνου -->
                    </div>
                </div>
            </div>
        </div>

        <script src="LogoutButton.js"></script> <!-- Αρχείο JavaScript για το κουμπί αποσύνδεσης -->
        <script src="StudentViewThesisButton.js"></script> <!-- JavaScript για το κουμπί προβολής θέματος -->
        <script src="StudentProfileButton.js"></script> <!-- JavaScript για το κουμπί προφίλ -->
        <script src="StudentManageThesisButton.js"></script> <!-- JavaScript για το κουμπί διαχείρισης -->
        <script src="submit.js"></script> <!-- Αρχείο JavaScript για υποβολές -->
        <script src="editButtonSt.js"></script> <!-- JavaScript για το κουμπί επεξεργασίας -->
    </body>
</html>