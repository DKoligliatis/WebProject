<!DOCTYPE html>
<html>
	
	<head>
		<!-- Τίτλος της σελίδας που εμφανίζεται στην καρτέλα -->
		<title id="titleMP">Διπλωματικές Εργασίες - Τμήμα Μηχανικών Η/Υ και Πληροφορικής</title>
		
		<!-- Ορισμός της εικόνας που εμφανίζεται στην καρτέλα -->
		<link rel="icon" type="image/png" href="ceid_logo.png">
		
		<!-- Σύνδεση με το εξωτερικό αρχείο CSS για την εμφάνιση της σελίδας -->
		<link rel="stylesheet" href="MainPage.css">
		
		<!-- Σύνδεση με το εξωτερικό αρχείο JavaScript για την λειτουργικότητα της σελίδας -->
        <script src="actions.js" defer></script>
		
	</head>
	
	<body>		
		
		<!-- Άνω τμήμα της σελίδας που περιέχει την εικόνα και το κουμπί εισόδου -->
		<div class="upper-section">
			
			<!-- Σύνδεσμος που παραπέμπει στην ιστοσελίδα του τμήματος -->
			<a href="https://www.ceid.upatras.gr" target="_self">
				<!-- Εικόνα του λογότυπου -->
				<img src="upatras_ceid_logo.png" alt="upatras_ceid_logo">
			</a>

			<!-- Κουμπί εισόδου που μπορεί να χρησιμοποιηθεί για σύνδεση στην πλατφόρμα -->
			<button class="login-button" id="login-buttonMP">Είσοδος</button>
		</div>

        <!-- Κύριο τμήμα της σελίδας που περιέχει εικόνα και κείμενο καλωσορίσματος -->
        <div class="main-section">
            <!-- Εικόνα του κτιρίου του τμήματος -->
            <img src="ceid_building.png" alt="ceid_building">
            
            <!-- Κείμενο που είναι πάνω από την εικόνα για την παρουσίαση πληροφοριών -->
            <div class="text-overlay">
                <!-- Τίτλος καλωσορίσματος στην πλατφόρμα -->
                <h3 id="h3MP"> Καλωσήρθατε στην Πλατφόρμα Διπλωματικών Εργασιών του Τμήματος Μηχανικών H/Y και Πληροφορικής</h3>
		        <!-- Παρουσίαση περιγραφής για την πλατφόρμα και τις διπλωματικές εργασίες -->
		        <p id="pMP">Εδώ θα ανακαλύψετε και θα εξερευνήσετε τις διπλωματικές εργασίες που μπορείτε να εκπονήσετε ως φοιτητές μας στο πλαίσιο της 
			    προετοιμασίας σας για τη μελλοντική σας σταδιοδρομία στην τεχνολογία και την καινοτομία. 
			    Από πρωτοποριακές λύσεις σε προκλήσεις της πληροφορικής έως εξελιγμένες εφαρμογές ηλεκτρονικών υπολογιστών, 
			    οι διπλωματικές μας εργασίες καλύπτουν ένα ευρύ φάσμα σύγχρονων τεχνολογικών θεμάτων και ερευνητικών πεδίων.
		        </p>

				<h3 id="h3MP">Προβολή Διπλωματικών Εργασιών Βάση Ημερομηνίας</h3>
    			<form method="POST" action="MainPage.php">
        			<!-- Επιλογή ημερομηνίας έναρξης -->
        			<label for="startDate">Ημερομηνία Έναρξης:</label>
        			<input type="date" id="startDate" name="startDate" required>
        			<br>
        			<!-- Επιλογή ημερομηνίας λήξης -->
        			<label for="endDate">Ημερομηνία Λήξης:</label>
        			<input type="date" id="endDate" name="endDate" required>
        			<br>
        			<!-- Κουμπί υποβολής για την εμφάνιση των διπλωματικών -->
        			<button type="submit">Εμφάνιση Διπλωματικών</button>
    			</form>
				
				 <!-- Εμφάνιση αποτελεσμάτων του query -->
				 <div id="results">
					<?php
					// Συμπερίληψη της ρύθμισης σύνδεσης με τη βάση δεδομένων
					require 'config.php';
	
					// Αν η μέθοδος της φόρμας είναι POST, επεξεργαζόμαστε τα δεδομένα
					if ($_SERVER['REQUEST_METHOD'] == 'POST') {
						// Αποθήκευση των ημερομηνιών από τη φόρμα
						$startDate = $_POST['startDate'];
						$endDate = $_POST['endDate'];
	
						// Ερώτημα για την αναζήτηση των διπλωματικών εργασιών βάση ημερομηνίας
						$sql = "
							SELECT 
								d.diplomaID,
								t.title AS diploma_title,
								t.description AS diploma_description,
								CONCAT(u.firstName, ' ', u.lastName) AS undergraduate_name,
								CONCAT(sup.firstName, ' ', sup.lastName) AS supervisor_name,
								CONCAT(m1.firstName, ' ', m1.lastName) AS committee_member_1,
								CONCAT(m2.firstName, ' ', m2.lastName) AS committee_member_2,
								d.startDate, d.endDate
							FROM Diplomas d
							INNER JOIN topics t ON d.topicID = t.topicID
							INNER JOIN undergraduates ug ON d.studentID = ug.studentID
							INNER JOIN users u ON ug.studentID = u.userID
							INNER JOIN committees c ON d.committeeID = c.committeeID
							INNER JOIN professors sup_p ON c.supervisorID = sup_p.profID
							INNER JOIN users sup ON sup_p.profID = sup.userID
							LEFT JOIN professors m1_p ON c.member1ID = m1_p.profID
							LEFT JOIN users m1 ON m1_p.profID = m1.userID
							LEFT JOIN professors m2_p ON c.member2ID = m2_p.profID
							LEFT JOIN users m2 ON m2_p.profID = m2.userID
							WHERE d.startDate >= ? AND d.endDate <= ?;
						";
	
						// Προετοιμασία και εκτέλεση του query με τις ημερομηνίες ως παραμέτρους
						$stmt = $conn->prepare($sql);
						$stmt->bind_param("ss", $startDate, $endDate);
						$stmt->execute();
						$result = $stmt->get_result();
	
						// Αν υπάρχουν αποτελέσματα, εμφανίζουμε τον πίνακα
						if ($result->num_rows > 0) {
							echo "<table border='1'>";
							echo "<tr>
									<th>Diploma ID</th>
									<th>Τίτλος</th>
									<th>Περιγραφή</th>
									<th>Όνομα Φοιτητή</th>
									<th>Όνομα Επιβλέπωντος Καθηγητή</th>
									<th>Μέλος Τριμελούς 1</th>
									<th>Μέλος Τριμελούς 2</th>
									<th>Ημερομηνία Έναρξης</th>
									<th>Ημερομηνία Λήξης</th>
								  </tr>";
	
							// Εμφάνιση των αποτελεσμάτων σε μορφή πίνακα
							while ($row = $result->fetch_assoc()) {
								echo "<tr>
										<td>{$row['diplomaID']}</td>
										<td>{$row['diploma_title']}</td>
										<td>{$row['diploma_description']}</td>
										<td>{$row['undergraduate_name']}</td>
										<td>{$row['supervisor_name']}</td>
										<td>{$row['committee_member_1']}</td>
										<td>{$row['committee_member_2']}</td>
										<td>{$row['startDate']}</td>
										<td>{$row['endDate']}</td>
									  </tr>";
							}
							echo "</table>";
						} else {
							// Αν δεν βρέθηκαν αποτελέσματα, εμφάνιση μηνύματος
							echo "<p>No diplomas found for the selected date range.</p>";
						}
	
						// Κλείσιμο της σύνδεσης και της εκτέλεσης του query
						$stmt->close();
						$conn->close();
					}
					?>
				</div>
            </div>
        </div>

		<!-- Κάτω τμήμα της σελίδας με πληροφορίες επικοινωνίας και επιλογή γλώσσας -->
		<div class="bottom-section">
			<div>
				<!-- Εικόνα του τμήματος -->
				<img src="ceid_symbol_black.png" alt="Ceid Symbol">
				
				<!-- Διεύθυνση του τμήματος για επικοινωνία -->
				<address>
					Οδός Ν. Καζαντζάκη (25ής Μαρτίου) |
					<br>26504 Ρίο, Πανεπιστημιούπολη Πατρών
				</address>
			</div>
			</div>
		</div>
	</body>
</html>
