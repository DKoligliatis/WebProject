<?php
require 'config.php';
session_start();

// Check if the form is submitted and handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Assuming you're processing multiple topics
    if (isset($_POST['title']) && isset($_POST['description']) && isset($_POST['filePath'])) {
        $profSupervID = $_SESSION['userID'];
        
        // Loop through each topic and update the database
        $titles = $_POST['title'];
        $descriptions = $_POST['description'];
        $filePaths = $_POST['filePath'];

        foreach ($titles as $index => $title) {
            $description = $descriptions[$index];
            $filePath = $filePaths[$index];

            // Update the record in the database
            $sql = "UPDATE topics SET title='$title', description='$description', filePath='$filePath' WHERE profSupervID='$profSupervID'";

            if ($conn->query($sql) === TRUE) {
                echo "Record updated successfully for topic $index!<br>";
            } else {
                echo "Error updating record for topic $index: " . $conn->error . "<br>";
            }
        }
    }
}
?>
