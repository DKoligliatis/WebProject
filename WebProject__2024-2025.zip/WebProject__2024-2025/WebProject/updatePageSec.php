<?php
session_start();

// Ανάκτηση δεδομένων χρήστη από τη συνεδρία
$userID = htmlspecialchars($_SESSION['userID']);
$firstName = htmlspecialchars($_SESSION['firstName']);
$lastName = htmlspecialchars($_SESSION['lastName']);
$email = htmlspecialchars($_SESSION['acEmail']);
$address = htmlspecialchars($_SESSION['address']);
$phoneMobile = htmlspecialchars($_SESSION['phone_mobile']);
$phoneHome = htmlspecialchars($_SESSION['phone_home']);
$AM = htmlspecialchars($_SESSION['AM']);
?>

<!DOCTYPE html>
<html>
    <head>
        <title>ΤΜΥΠ | Το προφίλ μου</title>
        <link rel="icon" type="image/png" href="ceid_logo.png">
        <link rel="stylesheet" href="updatePageSec.css">
    </head>
    <body>
        <div class="upper-section">
            <a href="https://www.ceid.upatras.gr" target="_self">
                <img src="upatras_ceid_logo.png" alt="upatras_ceid_logo">
            </a>
            <button class="logout-button" id="logout-button" onclick="window.location.href='logout.php'">Έξοδος</button>
        </div>

        <div class="container">  
            <div class="main-menu">   
                <!-- Κουμπί για το προφίλ της γραμματείας -->
                <button class="menu-item" id="profile">Προφίλ </button>
                
                <!-- Κουμπί για την προβολή των διπλωματικών εργασιών -->
                <button class="menu-item" id="view-thesis">Προβολή Διπλωματικών <br>Εργασιών</button>  
                
                <!-- Κουμπί για την εισαγωγή δεδομένων για τις διπλωματικές εργασίες -->
                <button class="menu-item" id="data-input">Εισαγωγή Δεδομένων </button>  
                
                <!-- Κουμπί για τη διαχείριση των διπλωματικών εργασιών -->
                <button class="menu-item" id="manage-thesis">Διαχείριση Διπλωματικής <br>Εργασίας </button>
            </div>  

            <div class="content">
                <div class="profile-container">
                    <div class="profile-header">
                        <img class="profile-picture" src="face.jpg" alt="Profile Picture">
                        <div class="profile-info">
                            <h1><?php echo $firstName . ' ' . $lastName; ?></h1>
                            <p><?php echo $AM; ?></p>
                        </div>
                    </div>

                    <div class="profile-details">
                        <h2>Προσωπικά Στοιχεία</h2>
                        <form id="update-profile-form">
                            <label for="email">E-mail:</label>
                            <input type="email" id="email" name="email" value="<?php echo $email; ?>" required>

                            <label for="address">Διεύθυνση:</label>
                            <input type="text" id="address" name="address" value="<?php echo $address; ?>">

                            <label for="phone_mobile">Κινητό:</label>
                            <input type="text" id="phone_mobile" name="phone_mobile" value="<?php echo $phoneMobile; ?>">

                            <label for="phone_home">Σταθερό:</label>
                            <input type="text" id="phone_home" name="phone_home" value="<?php echo $phoneHome; ?>">

                            <button type="submit" id="submit">Αποθήκευση Αλλαγών</button>
                        </form>
                        <p id="update-status"></p>
                    </div>
                </div>
            </div>
        </div>
        <script>
            // Χειρισμός υποβολής φόρμας
            document.getElementById('update-profile-form').addEventListener('submit', async (event) => {
                event.preventDefault(); // Ακύρωση της τυπικής υποβολής

                const formData = new FormData(event.target);

                const response = await fetch('updateProfile.php', {
                    method: 'POST',
                    body: formData
                });

                const result = await response.json();
                const statusElement = document.getElementById('update-status');

                if (result.success) {
                    statusElement.textContent = 'Τα στοιχεία ενημερώθηκαν επιτυχώς!';
                    statusElement.style.color = 'green';
                } else {
                    statusElement.textContent = 'Σφάλμα: ' + result.error;
                    statusElement.style.color = 'red';
                }
            });
        </script>
    <script src="LogoutButton.js"></script>
    <script src="SecretaryProfilePage.js"></script>
    <script src="SecretaryProfileButton.js"></script>      
    </body>
</html>


    

