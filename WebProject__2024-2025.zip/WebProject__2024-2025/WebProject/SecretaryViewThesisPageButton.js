document.getElementById("view-thesis").addEventListener("click", function() {
    window.location.href = 'SecretaryViewThesisPage.php';
});