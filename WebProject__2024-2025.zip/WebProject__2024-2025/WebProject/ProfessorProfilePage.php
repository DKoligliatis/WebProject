<?php
session_start();

// Ανάκτηση δεδομένων χρήστη από τη συνεδρία
$userID = htmlspecialchars($_SESSION['userID']);
$firstName = htmlspecialchars($_SESSION['firstName']);
$lastName = htmlspecialchars($_SESSION['lastName']);
$email = htmlspecialchars($_SESSION['acEmail']);
$address = htmlspecialchars($_SESSION['address']);
$phoneMobile = htmlspecialchars($_SESSION['phone_mobile']);
$phoneHome = htmlspecialchars($_SESSION['phone_home']);
?>

<!DOCTYPE html>
<html>
    <head>
        <!-- Τίτλος της σελίδας που εμφανίζεται στην καρτέλα -->
        <title>ΤΜΥΠ | Το προφίλ μου</title>
        
        <!-- Ορισμός της εικόνα που εμφανίζεται στην καρτέλα -->
        <link rel="icon" type="image/png" href="ceid_logo.png">
        
        <!-- Σύνδεση με το  αρχείο CSS για την εμφάνιση της σελίδας -->
        <link rel="stylesheet" href="ProfessorProfilePage.css">

    </head>

    <body>
        <!-- Άνω τμήμα της σελίδας με το λογότυπο και το κουμπί εξόδου -->
        <div class="upper-section">
			<!-- Σύνδεσμος για να επιστρέψει ο χρήστης στην ιστοσελίδα του τμήματος -->
			<a href="https://www.ceid.upatras.gr" target="_self">
				<!-- Εικόνα του λογότυπου του τμήματος -->
				<img src="upatras_ceid_logo.png" alt="upatras_ceid_logo">
			</a>

			<!-- Κουμπί εξόδου για αποσύνδεση από την πλατφόρμα -->
			<button class="logout-button"onclick="window.location.href='logout.php'">Έξοδος</button>
		</div>


        <!-- Κύριο περιεχόμενο της σελίδας -->
        <div class="container">  
            <div class="main-menu">   
                <!-- Κουμπί για το προφίλ του καθηγητή -->
                <button class="menu-item" id="profile">Προφίλ </button>
                
                <!-- Κουμπί για την προβολή και δημιουργία θεμάτων προς ανάθεση -->
                <button class="menu-item" id="view-and-create-thesis">Προβολή και Δημιουργία <br>Θεμάτων προς Ανάθεση</button>  
                
                <!-- Κουμπί για την αρχική ανάθεση θέματος σε φοιτητή -->
                <button class="menu-item" id="assign-thesis">Αρχική Ανάθεση Θέματος <br>σε Φοιτητή </button>  
                
                <!-- Κουμπί για την προβολή λίστας διπλωματικών εργασιών -->
                <button class="menu-item" id="view-list-thesis">Προβολή Λίστας <br>Διπλωματικών</button>

                <button class="menu-item" id="view-requests-3">Προβολή Προσκλήσεων <br> Συμμετοχής σε Τριμελή</button>
                                
                <!-- Κουμπί για την προβολή στατιστικών -->
                <button class="menu-item" id="view-sattistics">Προβολή Στατιστικών</button>
                
                <!-- Κουμπί για τη διαχείριση των διπλωματικών εργασιών -->
                <button class="menu-item" id="manage-thesis">Διαχείριση Διπλωματικών <br>Εργασιών</button>
            </div>  
            
            <div class="content">
                <!-- Προφίλ καθηγητή -->
                <div class="profile-container">
                    <div class="profile-header">
                        <!-- Εικόνα προφίλ του καθηγητή -->
                        <img class="profile-picture" src="face.jpg" alt="Profile Picture">
                        
                        <div class="profile-info">
                            <!-- Όνομα και στοιχεία του καθηγητή -->
                            <h1><?php echo $firstName . " " . $lastName?></h1>
                            <p><?php echo $userID?></p>
                        </div>
                        
                        <!-- Κουμπί για την επεξεργασία του προφίλ -->
                        <button class="edit-button" id="edit-buttonPr">Αλλαγή</button>
                    </div>
                    
                    <!-- Προσωπικά στοιχεία του καθηγητή -->
                    <div class="profile-details">
                        <h2>Προσωπικά Στοιχεία</h2>
                        <p><strong>E-mail:</strong> <?php echo $email?></p>
                        <p><strong>Αριθμός μητρώου:</strong> <?php echo $userID?></p>
                        <p><strong>Κατηγορία: </strong>Καθηγητής</p>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Σύνδεση με το αρχείο JavaScript για τη λειτουργία των κουμπιών -->
        <script src="ProfViewCreateThesisPageButton.js"></script>
        <script src="ProfAssignThesisPageButton.js"></script>
        <script src="ProfViewListThesisPageButton.js"></script> 
        <script src="ProfManageThesisPageButton.js"></script>
        <script src="ProfRequests3.js"></script>
        <script src="ProfStatistics.js"></script>
    </body>
</html>