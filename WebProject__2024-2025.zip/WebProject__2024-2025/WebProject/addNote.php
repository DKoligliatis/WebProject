<?php
require 'config.php';
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['diplomaID']) && isset($_POST['noteText'])) {
        $diplomaID = intval($_POST['diplomaID']);
        $noteText = trim($_POST['noteText']);
        $profID = $_SESSION['userID']; // Assuming the professor is logged in

        // Use prepared statements to prevent SQL Injection
        $query = "INSERT INTO diplomanotes (diplomaID, noteText, profID) VALUES (?, ?, ?)";
        $stmt = $conn->prepare($query);
        $stmt->bind_param('isi', $diplomaID, $noteText, $profID);

        if ($stmt->execute()) {
            echo "Επιτυχής προσθήκη σημείωσης";
        } else {
            echo "Σφάλμα κατά την προσθήκη σημείωσεις: " . $conn->error;
        }
    } else {
        echo "Invalid input.";
    }
}
?>
