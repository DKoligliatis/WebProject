document.getElementById("profile").addEventListener("click", function() {
    window.location.href = 'StudentProfilePage.php';
});