document.getElementById("edit-buttonSec").addEventListener("click", function() {
    window.location.href = 'updatePageSec.php';
});