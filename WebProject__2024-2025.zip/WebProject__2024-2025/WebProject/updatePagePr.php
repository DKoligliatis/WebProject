<?php
session_start();

// Ανάκτηση δεδομένων χρήστη από τη συνεδρία
$userID = htmlspecialchars($_SESSION['userID']);
$firstName = htmlspecialchars($_SESSION['firstName']);
$lastName = htmlspecialchars($_SESSION['lastName']);
$email = htmlspecialchars($_SESSION['acEmail']);
$address = htmlspecialchars($_SESSION['address']);
$phoneMobile = htmlspecialchars($_SESSION['phone_mobile']);
$phoneHome = htmlspecialchars($_SESSION['phone_home']);
$AM = htmlspecialchars($_SESSION['AM']);
?>

<!DOCTYPE html>
<html>
    <head>
        <title>ΤΜΥΠ | Το προφίλ μου</title> <!-- Τίτλος της σελίδας -->
        <link rel="icon" type="image/png" href="ceid_logo.png"> <!-- Εικονίδιο της σελίδας -->
        <link rel="stylesheet" href="updatePagePr.css"> <!-- Εξωτερικό CSS για μορφοποίηση -->
    </head>
    <body>
        <div class="upper-section">
            <a href="https://www.ceid.upatras.gr" target="_self"> <!-- Σύνδεσμος στην ιστοσελίδα του τμήματος -->
                <img src="upatras_ceid_logo.png" alt="upatras_ceid_logo"> <!-- Λογότυπο του τμήματος -->
            </a>
            <button class="logout-button" id="logout-button" onclick="window.location.href='logout.php'">Έξοδος</button>
            <!-- Κουμπί αποσύνδεσης που ανακατευθύνει στη σελίδα logout.php -->
        </div>

        <div class="container">  
            <div class="main-menu">   
                <!-- Κουμπί προβολής προφίλ -->
                <button class="menu-item" id="profile">Προφίλ </button> 
                <!-- Κουμπί προβολής και δημιουργίας θεμάτων -->
                <button class="menu-item" id="view-and-create-thesis">Προβολή και Δημιουργία <br> Θεμάτων προς Ανάθεση</button>
                <!-- Κουμπί ανάθεσης θέματος -->
                <button class="menu-item" id="assign-thesis">Αρχική Ανάθεση Θέματος <br> σε Φοιτητή </button>
                <!-- Κουμπί προβολής λίστας διπλωματικών -->
                <button class="menu-item" id="view-list-thesis">Προβολή Λίστας <br> Διπλωματικών</button>
                <!-- Κουμπί προσκλήσεων τριμελών επιτροπών -->
                <button class="menu-item" id="view-invites-to-3-person-exam">Προβολή Προσκλήσεων <br> Συμμετοχής σε Τριμελή</button>
                <!-- Κουμπί στατιστικών -->
                <button class="menu-item" id="view-sattistics">Προβολή Στατιστικών</button> 
                <!-- Κουμπί διαχείρισης διπλωματικών -->
                <button class="menu-item" id="manage-thesis">Διαχείριση Διπλωματικών <br> Εργασιών</button>
                
            </div>    

            <div class="content">
                <div class="profile-container">
                    <div class="profile-header">
                        <img class="profile-picture" src="face.jpg" alt="Profile Picture"> <!-- Εικόνα προφίλ -->
                        <div class="profile-info">
                            <h1><?php echo $firstName . ' ' . $lastName; ?></h1> <!-- Εμφάνιση ονοματεπωνύμου -->
                            <p><?php echo $AM; ?></p> <!-- Εμφάνιση αριθμού μητρώου -->
                        </div>
                    </div>

                    <div class="profile-details">
                        <h2>Προσωπικά Στοιχεία</h2> <!-- Ενότητα προσωπικών στοιχείων -->
                        <form id="update-profile-form"> <!-- Φόρμα για ενημέρωση προφίλ -->
                            <label for="email">E-mail:</label>
                            <input type="email" id="email" name="email" value="<?php echo $email; ?>" required>
                            <!-- Πεδία φόρμας για ενημέρωση στοιχείων -->
                            <label for="address">Διεύθυνση:</label>
                            <input type="text" id="address" name="address" value="<?php echo $address; ?>">

                            <label for="phone_mobile">Κινητό:</label>
                            <input type="text" id="phone_mobile" name="phone_mobile" value="<?php echo $phoneMobile; ?>">

                            <label for="phone_home">Σταθερό:</label>
                            <input type="text" id="phone_home" name="phone_home" value="<?php echo $phoneHome; ?>">

                            <button type="submit" id="submit">Αποθήκευση Αλλαγών</button> <!-- Κουμπί υποβολής -->
                        </form>
                        <p id="update-status"></p> <!-- Εμφάνιση μηνύματος κατάστασης -->
                    </div>
                </div>
            </div>
        </div>

        <script>
            // Χειρισμός υποβολής φόρμας
            document.getElementById('update-profile-form').addEventListener('submit', async (event) => {
                event.preventDefault(); // Ακύρωση της προεπιλεγμένης υποβολής φόρμας.

                const formData = new FormData(event.target); // Συλλογή δεδομένων φόρμας.

                const response = await fetch('updateProfile.php', { // Αποστολή δεδομένων στο updateProfile.php.
                    method: 'POST',
                    body: formData
                });

                const result = await response.json(); // Ανάγνωση απόκρισης JSON.
                const statusElement = document.getElementById('update-status'); // Επιλογή στοιχείου για μηνύματα κατάστασης.

                if (result.success) {
                    statusElement.textContent = 'Τα στοιχεία ενημερώθηκαν επιτυχώς!'; // Μήνυμα επιτυχίας.
                    statusElement.style.color = 'green';
                } else {
                    statusElement.textContent = 'Σφάλμα: ' + result.error; // Μήνυμα σφάλματος.
                    statusElement.style.color = 'red';
                }
            });
        </script>
        <script src="LogoutButton.js"></script> <!-- Αρχείο JavaScript για αποσύνδεση -->
        <script src="ProfessorProfileButton.js"></script> <!-- Αρχείο JavaScript για κουμπιά προφίλ -->
    </body>
</html>