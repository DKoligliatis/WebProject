document.getElementById("view-sattistics").addEventListener("click", function() {
    window.location.href = 'ProfStatistics.php';
});