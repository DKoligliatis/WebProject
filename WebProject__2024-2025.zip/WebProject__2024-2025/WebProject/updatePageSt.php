<?php
session_start();

// Ανάκτηση δεδομένων χρήστη από τη συνεδρία
$userID = htmlspecialchars($_SESSION['userID']);
$firstName = htmlspecialchars($_SESSION['firstName']);
$lastName = htmlspecialchars($_SESSION['lastName']);
$email = htmlspecialchars($_SESSION['acEmail']);
$address = htmlspecialchars($_SESSION['address']);
$phoneMobile = htmlspecialchars($_SESSION['phone_mobile']);
$phoneHome = htmlspecialchars($_SESSION['phone_home']);
$AM = htmlspecialchars($_SESSION['AM']);
?>

<!DOCTYPE html>
<html>
    <head>
        <!-- Ορίζει τον τίτλο της σελίδας και το εικονίδιο της σελίδας -->
        <title>ΤΜΥΠ | Το προφίλ μου</title>
        <link rel="icon" type="image/png" href="ceid_logo.png">
        <!-- Συνδέει το εξωτερικό αρχείο CSS για στυλ -->
        <link rel="stylesheet" href="updatePageSt.css">
    </head>
    <body>
        <!-- Ανώτερο τμήμα της σελίδας που περιλαμβάνει το λογότυπο του CEID και το κουμπί αποσύνδεσης -->
        <div class="upper-section">
            <a href="https://www.ceid.upatras.gr" target="_self">
                <!-- Λογότυπο του CEID με υπερσύνδεσμο -->
                <img src="upatras_ceid_logo.png" alt="upatras_ceid_logo">
            </a>
            <!-- Κουμπί εξόδου με υπερσύνδεσμο προς την έξοδο της σελίδας -->
            <button class="logout-button" id="logout-button" onclick="window.location.href='logout.php'">Έξοδος</button>
        </div>

        <!-- Κεντρικό τμήμα της σελίδας με μενού και περιεχόμενο -->
        <div class="container">  
            <!-- Κεντρικό μενού επιλογών -->
            <div class="main-menu">   
                <!-- Κουμπιά για την επιλογή του προφίλ, προβολής και διαχείρισης της διπλωματικής εργασίας -->
                <button class="menu-item" id="profile">Προφίλ</button>
                <button class="menu-item" id="view-thesis">Προβολή θεμάτων <br>Διπλωματικής Εργασίας</button>  
                <button class="menu-item" id="manage-thesis">Διαχείριση Διπλωματικής <br>Εργασίας</button>  
            </div>  

            <!-- Κύριο περιεχόμενο της σελίδας που περιλαμβάνει τα προσωπικά στοιχεία -->
            <div class="content">
                <div class="profile-container">
                    <!-- Κεφάλαιο του προφίλ με την φωτογραφία και τα προσωπικά δεδομένα -->
                    <div class="profile-header">
                        <img class="profile-picture" src="face.jpg" alt="Profile Picture">
                        <div class="profile-info">
                            <!-- Εκτύπωση του ονόματος και του ΑΜ -->
                            <h1><?php echo $firstName . ' ' . $lastName; ?></h1>
                            <p><?php echo $AM; ?></p>
                        </div>
                    </div>

                    <div class="profile-details">
                        <!-- Ενότητα για τα προσωπικά στοιχεία -->
                        <h2>Προσωπικά Στοιχεία</h2>
                        <form id="update-profile-form">
                            <!-- Ετικέτες και πεδία φόρμας για ενημέρωση των στοιχείων -->
                            <label for="email">E-mail:</label>
                            <input type="email" id="email" name="email" value="<?php echo $email; ?>" required>

                            <label for="address">Διεύθυνση:</label>
                            <input type="text" id="address" name="address" value="<?php echo $address; ?>">

                            <label for="phone_mobile">Κινητό:</label>
                            <input type="text" id="phone_mobile" name="phone_mobile" value="<?php echo $phoneMobile; ?>">

                            <label for="phone_home">Σταθερό:</label>
                            <input type="text" id="phone_home" name="phone_home" value="<?php echo $phoneHome; ?>">

                            <!-- Κουμπί υποβολής για την αποθήκευση των αλλαγών -->
                            <button type="submit" id="submit">Αποθήκευση Αλλαγών</button>
                        </form>
                        <!-- Πεδίο για εμφάνιση μηνύματος επιτυχίας ή αποτυχίας -->
                        <p id="update-status"></p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Σκριπτ JavaScript για την υποβολή της φόρμας χωρίς ανανέωση της σελίδας -->
        <script>
            // Χειρισμός υποβολής φόρμας
            document.getElementById('update-profile-form').addEventListener('submit', async (event) => {
                event.preventDefault(); // Ακύρωση της τυπικής υποβολής

                // Συναρμολόγηση των δεδομένων της φόρμας
                const formData = new FormData(event.target);

                // Αποστολή των δεδομένων στον διακομιστή με χρήση της μεθόδου POST
                const response = await fetch('updateProfile.php', {
                    method: 'POST',
                    body: formData
                });

                // Ανάγνωση της απόκρισης του διακομιστή
                const result = await response.json();
                const statusElement = document.getElementById('update-status');

                // Εμφάνιση του μηνύματος επιτυχίας ή αποτυχίας
                if (result.success) {
                    statusElement.textContent = 'Τα στοιχεία ενημερώθηκαν επιτυχώς!';
                    statusElement.style.color = 'green';
                } else {
                    statusElement.textContent = 'Σφάλμα: ' + result.error;
                    statusElement.style.color = 'red';
                }
            });
        </script>

        <!-- Σκριπτ για την επεξεργασία κουμπιών -->
        <script src="LogoutButton.js"></script>
        <script src="StudentViewThesisButton.js"></script>
        <script src="StudentProfileButton.js"></script>
        <script src="StudentManageThesisButton.js"></script>
        <script src="editButton.js"></script>       
    </body>
</html>