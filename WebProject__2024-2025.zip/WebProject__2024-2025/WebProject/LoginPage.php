<?php
// Εισάγει το αρχείο ρυθμίσεων της βάσης δεδομένων και των παραμέτρων σύνδεσης
require 'config.php'; 
// Ξεκινά μια νέα συνεδρία ή συνεχίζει την υπάρχουσα
session_start(); 
?>

<!DOCTYPE html>
<html lang="el">
<head>
    <!-- Ορίζει τη μορφοποίηση χαρακτήρων της σελίδας σε UTF-8 -->
    <meta charset="UTF-8"> 
    <!-- Ορίζει το μέγεθος της σελίδας σε κινητές συσκευές -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
    <!-- Τίτλος που εμφανίζεται στην καρτέλα του προγράμματος περιήγησης -->
    <title id="titleLP">Κεντρική Υπηρεσία Ταυτοποίησης & Εξουσιοδότησης</title> 
    <!-- Εικονίδιο που εμφανίζεται στην καρτέλα του προγράμματος περιήγησης -->
    <link rel="icon" type="image/png" href="ceid_logo.png"> 
    <!-- Σύνδεση με το εξωτερικό αρχείο CSS για το στυλ της σελίδας -->
    <link rel="stylesheet" href="LoginPage.css"> 
</head>
<body>

    <!-- Σύνδεσμος προς την ιστοσελίδα του τμήματος με λογότυπο -->
    <a href="https://www.ceid.upatras.gr" target="_self">
        <img src="upatras_ceid_logo.png" alt="Λογότυπο Τμήματος Πληροφορικής">
    </a>
    
    <!-- Κοντέινερ για τη φόρμα εισόδου -->
    <div class="login-container"> 
        <!-- Τίτλος της σελίδας Εισόδου -->
        <h2 id="headerLP">Είσοδος</h2> 
        
        <!-- Εμφάνιση μηνύματος σφάλματος αν υπάρχει -->
        <?php if (isset($_GET['error']) && $_GET['error'] == 'invalid_credentials'): ?>
            <!-- Μήνυμα λάθους για εσφαλμένα διαπιστευτήρια -->
            <p style="color: red;">Λάθος όνομα χρήστη ή κωδικός.</p> 
        <?php endif; ?>
        
        <!-- Φόρμα που στέλνει τα δεδομένα για έλεγχο σύνδεσης -->
        <form action="Login.php" method="POST"> 
            <!-- Πεδίο για το όνομα χρήστη -->
            <input type="text" class="input-field" id="acEmail" name="acEmail" placeholder="Όνομα Χρήστη" required><br> 
            
            <!-- Πεδίο για τον κωδικό -->
            <input type="password" class="input-field" id="password" name="password" placeholder="Κωδικός" required><br> 
            
            <!-- Checkbox για εμφάνιση/απόκρυψη του κωδικού -->
            <label>
                <input type="checkbox" id="showPassword"> Εμφάνιση Κωδικού
            </label><br>
            
            <!-- Κουμπί υποβολής φόρμας για σύνδεση -->
            <button type="submit" class="login-button" id="loginButton">Σύνδεση</button> 
        </form>
        
        <!-- Σύνδεσμος για ανάκτηση κωδικού -->
        <a href="ResetPasswordPage.php" class="forgot-password" id="forgotPassword">Ξέχασες τον κωδικό σου;</a> 
    </div>

    <script>
        // Παίρνει το checkbox για εμφάνιση κωδικού
        const showPassword = document.getElementById('showPassword'); 
        // Παίρνει το πεδίο του κωδικού
        const passwordField = document.getElementById('password'); 

        // Αλλαγή του τύπου του πεδίου του κωδικού σε κείμενο ή password αναλόγως του αν είναι τσεκαρισμένο το checkbox
        showPassword.addEventListener('change', () => {
            passwordField.type = showPassword.checked ? 'text' : 'password'; 
        });
    </script>
</body>
</html>