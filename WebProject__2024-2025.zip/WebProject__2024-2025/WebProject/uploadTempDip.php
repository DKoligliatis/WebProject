<?php
require 'config.php';
session_start();

$response = []; // Array to hold response

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $studentID = $_SESSION['userID']; // Assuming the student is logged in
    $file = $_FILES['pdf_file']; // PDF file uploaded by the student

    try {
        $filePath = null;

        // Check if a file was uploaded and there were no errors
        if (isset($file) && $file['error'] == 0) {
            $fileTmpName = $file['tmp_name'];
            $filePath = file_get_contents($fileTmpName); // Get file contents as binary data
        }

        // Prepare the query to update the tempFile column for the student
        $stmt = $conn->prepare("UPDATE diplomas SET tempFile = ? WHERE studentID = ? AND Status = 'Under Review'");
        $stmt->bind_param("si", $filePath, $studentID);

        // Execute the query
        if ($stmt->execute()) {
            $response = ["status" => "success", "message" => "Το αρχείο ανέβηκε επιτυχώς!"];
        } else {
            $response = ["status" => "error", "message" => "Σφάλμα κατά την αποθήκευση του αρχείου: " . $stmt->error];
        }

        $stmt->close();
    } catch (Exception $e) {
        $response = ["status" => "error", "message" => "An unexpected error occurred: " . $e->getMessage()];
    }
}

$conn->close();
header('Content-Type: application/json');
echo json_encode($response);
?>
