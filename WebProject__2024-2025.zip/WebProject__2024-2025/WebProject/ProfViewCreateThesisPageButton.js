document.getElementById("view-and-create-thesis").addEventListener("click", function() {
    window.location.href = 'ProfViewCreateThesisPage.php';
});