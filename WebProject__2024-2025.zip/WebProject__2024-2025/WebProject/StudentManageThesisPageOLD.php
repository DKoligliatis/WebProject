<?php
require 'config.php';
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'];

    if ($action === 'getProfessors') {
        // Επιστροφή λίστας καθηγητών
        $sql = "SELECT profID, CONCAT(firstName, ' ', lastName) AS fullName 
                FROM professors JOIN users ON professors.profID = users.userID";
       
       $result = $conn->query($sql);

        if (!$result) {
            die("Database query failed: " . $conn->error);
        }

        $professors = [];
        while ($row = $result->fetch_assoc()) {
            $professors[] = $row;
        }

        echo json_encode($professors);
        exit();
    }

    if ($action === 'sendInvitation') {
        // Αποστολή αίτησης μέσω της `sendInvitation`
        $studentID = $_SESSION['userID'];
        $professorID = $_POST['professorID'];

        try {
            $stmt = $conn->prepare("CALL sendInvitation(?, ?)");
            $stmt->bind_param("ii", $studentID, $professorID);
            $stmt->execute();
            echo json_encode(['success' => true, 'message' => 'Η αίτηση στάλθηκε επιτυχώς.']);
        } catch (Exception $e) {
            echo json_encode(['success' => false, 'message' => $e->getMessage()]);
        }
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="el">
<head>
    <!-- Τίτλος της σελίδας -->
    <title>ΤΜΥΠ | Προβολή Διπλωματικής Εργασίας</title>
    
    <!-- Εικόνα που εμφανίζεται στην καρτέλα -->
    <link rel="icon" type="image/png" href="ceid_logo.png">
    
    <!-- Σύνδεση με το αρχείο CSS -->
    <link rel="stylesheet" href="StudentManageThesisPage.css">
</head>
<body>
    <!-- Άνω τμήμα της σελίδας -->
    <div class="upper-section">
        <a href="https://www.ceid.upatras.gr" target="_self">
            <img src="upatras_ceid_logo.png" alt="upatras_ceid_logo">
        </a>
        <button class="logout-button" id="logout-button" onclick="window.location.href='logout.php'">Έξοδος</button>
    </div>

    <!-- Περιεχόμενο της σελίδας -->
    <div class="container">
        <div class="main-menu">
            <button class="menu-item" id="profile" onclick="window.location.href='StudentProfilePage.php'">Προφίλ</button>
            <button class="menu-item" id="view-thesis" onclick="window.location.href='StudentViewThesis.php'">Προβολή Θέματος<br>Διπλωματικής Εργασίας</button>
            <button class="menu-item" id="manage-thesis" onclick="window.location.href='StudentManageThesisPage.php'">Διαχείριση Διπλωματικής<br>Εργασίας</button>
        </div>
    </div>
    
    <div class="content">
        <h1>Αποστολή Αίτησης σε Καθηγητή</h1>
        <form id="send-invitation-form">
            <label for="professor-select"><h3>Επιλέξτε Καθηγητή:</h3></label>
            <select id="professor-select">
                <!-- Δυναμική φόρτωση καθηγητών -->
            </select>
            <button type="submit" id="submit">Αποστολή</button>
        </form>

    <form action="uploadTempDip.php" method="POST" enctype="multipart/form-data">
       
        <label for="pdf_file">Choose PDF file to upload:</label><br>
        <input type="file" id="pdf_file" name="pdf_file" accept=".pdf" required><br><br>

        <input type="submit" value="Upload Draft">
    </form>

    </div>

    <script>
        // Φόρτωση Καθηγητών
        window.onload = () => {
            fetch('StudentManageThesisPage.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: 'action=getProfessors'
            })
                .then(response => response.json())
                .then(data => {
                    const professorSelect = document.getElementById('professor-select');
                    data.forEach(professor => {
                        const option = document.createElement('option');
                        option.value = professor.profID;
                        option.textContent = professor.fullName;
                        professorSelect.appendChild(option);
                    });
                })
                .catch(error => {
                    console.error('Error loading professors:', error);
                    alert('Σφάλμα κατά τη φόρτωση των καθηγητών.');
                });
        };

    // Αποστολή Αίτησης
    document.getElementById('send-invitation-form').addEventListener('submit', (event) => {
    event.preventDefault(); // Ακύρωση της τυπικής υποβολής φόρμας

    const professorID = document.getElementById('professor-select').value;
    const statusMessage = document.getElementById('status-message');
    // Έλεγχος αν έχει επιλεχθεί καθηγητής
    if (!professorID) {
        alert("Παρακαλώ επιλέξτε καθηγητή πριν αποστείλετε την αίτηση.");
        return;
    }

    fetch('StudentManageThesisPage.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: `action=sendInvitation&professorID=${professorID}`
    })
        .then(response => response.json()) // Μετατροπή του response σε JSON
        .then(data => {
            if (data.success) {
                alert("Επιτυχία: " + data.message);
            } else {
                alert("Σφάλμα: " + data.message);
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert("Παρουσιάστηκε πρόβλημα κατά την αποστολή της αίτησης.");
        });
});

    </script>
</body>
</html>
