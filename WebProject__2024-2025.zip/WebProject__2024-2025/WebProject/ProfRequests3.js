document.getElementById("view-requests-3").addEventListener("click", function() {
    window.location.href = 'ProfRequests3.php';
});