<?php
session_start();
require 'config.php';
?>

<!DOCTYPE html>
<html>
    <head>
        <!-- Τίτλος της σελίδας που εμφανίζεται στην καρτέλα -->
        <title>ΤΜΥΠ | Προβολή Διπλωματικών Εργασιών</title>
        
        <!-- Ορισμός της εικόνας που εμφανίζεται στην καρτέλα -->
        <link rel="icon" type="image/png" href="ceid_logo.png">
        
        <!-- Σύνδεση με το αρχείο CSS για την εμφάνιση της σελίδας -->
        <link rel="stylesheet" href="SecretaryViewThesisPage.css">
        
    </head>

    <body>
        <!-- Άνω τμήμα της σελίδας με το λογότυπο και το κουμπί εξόδου -->
        <div class="upper-section">
			<!-- Σύνδεσμος για να επιστρέψει ο χρήστης στην ιστοσελίδα του τμήματος -->
			<a href="https://www.ceid.upatras.gr" target="_self">
				<!-- Εικόνα του λογότυπου του τμήματος -->
				<img src="upatras_ceid_logo.png" alt="upatras_ceid_logo">
			</a>

			<!-- Κουμπί εξόδου για αποσύνδεση από την πλατφόρμα -->
			<button class="logout-button"onclick="window.location.href='logout.php'">Έξοδος</button>
		</div>

        <!-- Κουμπί για την αλλαγή γλώσσας της σελίδας -->
        <div class="language-toggle">
            <button id="languageButton">
                <!-- Εικονίδιο που δείχνει την επιλογή γλώσσας -->
                <img src="language.png" alt="languageIcon">
            </button>
        </div>
		
        <!-- Κύριο περιεχόμενο της σελίδας -->
        <div class="container">  
            <div class="main-menu">   
                <!-- Κουμπί για το προφίλ της γραμματείας -->
                <button class="menu-item" id="profile">Προφίλ </button>
                
                <!-- Κουμπί για την προβολή των διπλωματικών εργασιών -->
                <button class="menu-item" id="view-thesis">Προβολή Διπλωματικών <br>Εργασιών</button>  
                
                <!-- Κουμπί για την εισαγωγή δεδομένων για τις διπλωματικές εργασίες -->
                <button class="menu-item" id="data-input">Εισαγωγή Δεδομένων </button>  
                
        </div>  
            
            <div class="content">
                <h1>Λίστα Διπλωματικών Εργασιών</h1>
                
            <?php

            global $conn;

            $sql = "SELECT 
    d.diplomaID AS diplomaID,
    t.title AS topicTitle,
    t.topicID AS topicID,
    d.status AS status,
    c.committeeID AS comID,
    d.Grade AS grade,
    CONCAT(sup_user.firstName, ' ', sup_user.lastName) AS supervisorName,
    CONCAT(mem1_user.firstName, ' ', mem1_user.lastName) AS member1Name,
    CONCAT(mem2_user.firstName, ' ', mem2_user.lastName) AS member2Name,
    CONCAT(student_user.firstName, ' ', student_user.lastName) AS studentName,
    d.nhmerthsLink as nhmerthsLink
FROM 
    diplomas d
JOIN 
    committees c ON d.committeeID = c.committeeID
JOIN 
    topics t ON d.topicID = t.topicID
LEFT JOIN 
    professors sup ON c.supervisorID = sup.profID
LEFT JOIN 
    users sup_user ON sup.profID = sup_user.userID
LEFT JOIN 
    professors mem1 ON c.member1ID = mem1.profID
LEFT JOIN 
    users mem1_user ON mem1.profID = mem1_user.userID
LEFT JOIN 
    professors mem2 ON c.member2ID = mem2.profID
LEFT JOIN 
    users mem2_user ON mem2.profID = mem2_user.userID
JOIN 
    undergraduates u ON d.studentID = u.studentID
JOIN 
    users student_user ON u.studentID = student_user.userID
WHERE 
    t.status = 'Assigned'";

            $result1 = mysqli_query($conn, $sql);

            // Αν υπάρχουν αποτελέσματα, τα προβάλλουμε σε πίνακα
            if (mysqli_num_rows($result1) > 0) {
                echo "<table border='1'>";
                echo "<tr>
                        <th>Diploma ID</th>
                        <th>Topic ID</th>
                        <th>ID Τριμελούς</th>
                        <th>Τίτλος Θέματος</th>
                        <th>Κατάσταση</th>
                        <th>Όνομα Φοιτητή</th>
                        <th>Όνομα Επιβλέποντα</th>
                        <th>Όνομα Μέλους 1</th>
                        <th>Όνομα Μέλους 2</th>
                        <th>Βαθμός</th>                        
                        <th>Ενέργεια</th>
                    </tr>";
                
                while ($row = mysqli_fetch_assoc($result1)) {
                    echo "<tr>";
                    echo "<td>" . htmlspecialchars($row['diplomaID']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['topicID']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['comID']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['topicTitle']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['status']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['studentName']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['supervisorName']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['member1Name']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['member2Name']) . "</td>";  
                    echo "<td>" . htmlspecialchars($row['grade']) . "</td>";                    
                    
                    echo "<td>";
                    
                
                        if ($row['status'] === 'Temporarily Assigned') {
                            echo "<form action='CancelCommittee.php' method='POST'>
                                <input type='hidden' name='committeeID' value='" . htmlspecialchars($row['comID']) . "'>
                                <input type='hidden' name='topicID' value='" . htmlspecialchars($row['topicID']) . "'>
                                <button type='submit' class='cancel-button'>Ακύρωση</button>
                            </form>";
                        } elseif ($row['status'] === 'In Progress') {
                            echo "<form action='addNote.php' method='POST' id='addNoteForm" . $row['comID'] . "' style='display:none;'> 
                            <textarea name='noteText' id='noteText" . $row['comID'] . "' maxlength='300' placeholder='Enter your note here'></textarea><br>
                            <button type='button' class='save-note-button' onclick='saveNote(" . $row['comID'] . ", " . $row['topicID'] . ")'>Αποθήκευση Σημείωσης</button>
                            </form>";
                            echo "<button class='add-note-button' onclick='toggleNoteInput(" . $row['comID'] . ")'>Προσθήκη Σημείωσης</button>";
                            
                            echo "<form action='changeStatus.php' method='POST'>
                                <input type='hidden' name='topicID' value='" . htmlspecialchars($row['topicID']) . "'>
                                <button type='submit' class='change-status-button'>Αλλαγή Κατάστασης</button>
                                </form>";
                            
                
                            echo "<form action='cancelDiploma.php' method='POST' id='cancelDiplomaForm'>
                                <input type='hidden' name='topicID' value='" . htmlspecialchars($row['topicID']) . "'>
                                
                                <!-- Button to trigger visibility of the text areas -->
                                <button type='button' class='cancel-diploma-button' id='showCancelFieldsBtn'>Ακύρωση</button>
                        
                                <!-- Hidden text areas that will show up when the button is clicked -->
                                <div id='cancelFields' style='display: none;'>
                                    <label for='cancelReason" . $row['comID'] . "'>Λόγος Ακύρωσης:</label>
                                    <textarea name='cancelReason' id='cancelReason" . $row['comID'] . "' maxlength='300' placeholder='Πληκτρολογήστε τον λόγο ακύρωσης'></textarea><br>
                                    
                                    <br><label for='assemblyYear" . $row['comID'] . "'>Έτος Συγκρότησης:</label>
                                    <input type='text' name='assemblyYear' id='assemblyYear" . $row['comID'] . "' placeholder='Πληκτρολογήστε το έτος' /><br>
                                    
                                    <br><label for='assemblyNumber" . $row['comID'] . "'>Αριθμός Συγκρότησης:</label>
                                    <input type='text' name='assemblyNumber' id='assemblyNumber" . $row['comID'] . "' placeholder='Πληκτρολογήστε τον αριθμό' /><br>
                        
                                    <br><button type='submit' class='submit-diploma-button'>Υποβολή Ακύρωσης</button>
                                </div>
                            </form>";
                        }elseif ($row['status'] === 'Under Review'){
                            if (!is_null($row['grade']) && !is_null($row['nhmerthsLink'])){
                                echo "<form action='CompleteDiploma.php' method='POST'>
                                <input type='hidden' name='topicID' value='" . htmlspecialchars($row['topicID']) . "'>
                                <button type='submit' class='change-status-button'>Αλλαγή Κατάστασης</button>
                                </form>";
                            }
                            
                        }
                        echo "</td>";
                    echo "</tr>";
                    }
                    echo "</table>";
                }else {
                    echo "Δεν βρέθηκαν αποτελέσματα.";
                }
                ?>

            </div>

        </div>
        
<script>
function toggleNoteInput(comID) {
const form = document.getElementById('addNoteForm' + comID);
form.style.display = form.style.display === 'none' ? 'block' : 'none';
}

function saveNote(comID, topicID) {
const noteText = document.getElementById('noteText' + comID).value;
const formData = new FormData();
formData.append('noteText', noteText);
formData.append('topicID', topicID);

fetch('addNote.php', {
    method: 'POST',
    body: formData
})
.then(response => response.text())
.then(data => {
    alert(data); // Optionally handle the response, show success/failure message
    
    // Hide the text input area and Save button after successful save
    const form = document.getElementById('addNoteForm' + comID);
    form.style.display = 'none';
})
.catch(error => console.error('Error:', error));
}

function changeStatus(topicID) {
const formData = new FormData();
formData.append('topicID', topicID);

fetch('changeStatus.php', {
    method: 'POST',
    body: formData
})
.then(response => response.text())
.then(data => {
    alert(data); // Show the response message in an alert

    // Optionally, hide the Change Status button or perform other actions after success
    const statusButton = document.getElementById('change-status-button-' + topicID);
    statusButton.style.display = 'none'; // Hide the button after successful status change
})
.catch(error => console.error('Error:', error));
}

// Attach the event listener to the button for each topic
document.querySelectorAll('.change-status-button').forEach(button => {
button.addEventListener('click', function() {
    const topicID = this.dataset.topicId; // Get the topicID from the data attribute
    changeStatus(topicID);
});
});

function toggleCancelForm(comID) {
const form = document.getElementById('cancelForm' + comID);
form.style.display = form.style.display === 'none' ? 'block' : 'none';
}

document.getElementById('showCancelFieldsBtn').addEventListener('click', function() {
var cancelFields = document.getElementById('cancelFields');
if (cancelFields.style.display === 'none') {
    cancelFields.style.display = 'block'; // Show the fields
} else {
    cancelFields.style.display = 'none'; // Hide the fields if clicked again
}
});
</script>
        
        <!-- Σύνδεση με το αρχείο JavaScript για τη λειτουργία του κουμπιού εξόδου -->
        <script src="LogoutButton.js"></script>
        <script src="SecretaryProfileButton.js"></script>
        <script src="SecretaryInsertDataPageButton.js"></script>
    </body>
</html>