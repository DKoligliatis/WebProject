<?php
require 'config.php';
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $profID = $_SESSION['userID'];

    // Καθορισμός των queries
    $queries = [
        'avgCompletionTimeSupervised' => "SELECT AVG(DATEDIFF(endDate, startDate)) AS value FROM diplomas WHERE committeeID IN (SELECT committeeID FROM committees WHERE supervisorID = ?)",
        'avgCompletionTimeMember' => "SELECT AVG(DATEDIFF(endDate, startDate)) AS value FROM diplomas WHERE committeeID IN (SELECT committeeID FROM committees WHERE member1ID = ? OR member2ID = ?)",
        'avgGradeSupervised' => "SELECT AVG(Grade) AS value FROM diplomas WHERE committeeID IN (SELECT committeeID FROM committees WHERE supervisorID = ?)",
        'avgGradeMember' => "SELECT AVG(Grade) AS value FROM diplomas WHERE committeeID IN (SELECT committeeID FROM committees WHERE member1ID = ? OR member2ID = ?)",
        'totalSupervised' => "SELECT COUNT(*) AS value FROM diplomas WHERE committeeID IN (SELECT committeeID FROM committees WHERE supervisorID = ?)",
        'totalMember' => "SELECT COUNT(*) AS value FROM diplomas WHERE committeeID IN (SELECT committeeID FROM committees WHERE member1ID = ? OR member2ID = ?)"
    ];

    $statistics = [];

    foreach ($queries as $key => $query) {
        $stmt = $conn->prepare($query);
        if (strpos($key, 'Member') !== false) {
            $stmt->bind_param("ii", $profID, $profID);
        } else {
            $stmt->bind_param("i", $profID);
        }
        $stmt->execute();
        $result = $stmt->get_result()->fetch_assoc();
        $statistics[$key] = $result['value'];
    }

    echo json_encode(['success' => true, 'statistics' => $statistics]);
    exit();
}
?>
<!DOCTYPE html>
<html lang="el">
<head>
    <meta charset="UTF-8">
    <title>ΤΜΥΠ | Προβολή Στατιστικών</title>
    <link rel="icon" type="image/png" href="ceid_logo.png">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <link rel="stylesheet" href="ProfStatistics.css">
</head>
<body>
    <div class="container">
         <!-- Άνω τμήμα της σελίδας με το λογότυπο και το κουμπί εξόδου -->
        <div class="upper-section">
			<!-- Σύνδεσμος για να επιστρέψει ο χρήστης στην ιστοσελίδα του τμήματος -->
			<a href="https://www.ceid.upatras.gr" target="_self">
				<!-- Εικόνα του λογότυπου του τμήματος -->
				<img src="upatras_ceid_logo.png" alt="upatras_ceid_logo">
			</a>

			<!-- Κουμπί εξόδου για αποσύνδεση από την πλατφόρμα -->
			<button class="logout-button"onclick="window.location.href='logout.php'">Έξοδος</button>
	</div>
    <div class="container">  
        <div class="main-menu">   
            <!-- Κουμπί για το προφίλ του καθηγητή -->
            <button class="menu-item" id="profile">Προφίλ </button>
            
            <!-- Κουμπί για την προβολή και δημιουργία θεμάτων προς ανάθεση -->
            <button class="menu-item" id="view-and-create-thesis">Προβολή και Δημιουργία <br>Θεμάτων προς Ανάθεση</button>  
            
            <!-- Κουμπί για την αρχική ανάθεση θέματος σε φοιτητή -->
            <button class="menu-item" id="assign-thesis">Αρχική Ανάθεση Θέματος <br>σε Φοιτητή </button>  
            
            <!-- Κουμπί για την προβολή λίστας διπλωματικών εργασιών -->
            <button class="menu-item" id="view-list-thesis">Προβολή Λίστας <br>Διπλωματικών</button>

            <button class="menu-item" id="view-requests-3">Προβολή Προσκλήσεων <br> Συμμετοχής σε Τριμελή</button>

            <!-- Κουμπί για την προβολή στατιστικών -->
            <button class="menu-item" id="view-sattistics">Προβολή Στατιστικών</button>
            
            <!-- Κουμπί για τη διαχείριση των διπλωματικών εργασιών -->
            <button class="menu-item" id="manage-thesis">Διαχείριση Διπλωματικών <br>Εργασιών</button>
            </div>  
    <div class="content ">

    <h1>Προβολή Στατιστικών</h1>
    <div class="charts-container">
    <div class="chart">
        <canvas id="completionTimeChart"></canvas>
    </div>
    <div class="chart">
        <canvas id="gradeChart"></canvas>
    </div>
    <div class="chart">
        <canvas id="countChart"></canvas>
    </div>
</div>


    <script>
        function fetchStatistics() {
            fetch('ProfStatistics.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' }
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    const stats = data.statistics;

                    // Γράφημα: Μέσος Χρόνος Περάτωσης
                    const completionTimeCtx = document.getElementById('completionTimeChart').getContext('2d');
                    new Chart(completionTimeCtx, {
                        type: 'bar',
                        data: {
                            labels: ['Επιβλέπων', 'Μέλος Τριμελούς'],
                            datasets: [{
                                label: 'Μέσος Χρόνος Περάτωσης (Ημέρες)',
                                data: [stats.avgCompletionTimeSupervised, stats.avgCompletionTimeMember],
                                backgroundColor: ['#4caf50', '#2196f3']
                            }]
                        }
                    });

                    // Γράφημα: Μέσος Βαθμός
                    const gradeCtx = document.getElementById('gradeChart').getContext('2d');
                    new Chart(gradeCtx, {
                        type: 'bar',
                        data: {
                            labels: ['Επιβλέπων', 'Μέλος Τριμελούς'],
                            datasets: [{
                                label: 'Μέσος Βαθμός',
                                data: [stats.avgGradeSupervised, stats.avgGradeMember],
                                backgroundColor: ['#ff9800', '#3f51b5']
                            }]
                        }
                    });

                    // Γράφημα: Πλήθος Διπλωματικών
                    const countCtx = document.getElementById('countChart').getContext('2d');
                    new Chart(countCtx, {
                        type: 'pie',
                        data: {
                            labels: ['Επιβλέπων', 'Μέλος Τριμελούς'],
                            datasets: [{
                                data: [stats.totalSupervised, stats.totalMember],
                                backgroundColor: ['#f44336', '#9c27b0']
                            }]
                        }
                    });
                } else {
                    alert('Σφάλμα κατά την ανάκτηση των στατιστικών.');
                }
            });
        }

        window.onload = fetchStatistics;
    </script>
    <script src="LogoutButton.js"></script>
<script src="editButtonProf.js"></script> 
<script src="ProfViewCreateThesisPageButton.js"></script>
<script src="ProfAssignThesisPageButton.js"></script>
<script src="ProfViewListThesisPageButton.js"></script> 
<script src="ProfManageThesisPageButton.js"></script>
<script src="ProfessorProfileButton.js"></script>
<script src="ProfRequests3.js"></script>
<script src="ProfStatistics.js"></script>
</body>
</html>


