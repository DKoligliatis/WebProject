<?php
require 'config.php'; // Σύνδεση με τη βάση δεδομένων

session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['acEmail'];
    $password = $_POST['password'];

    $sql = "SELECT * FROM users LEFT JOIN undergraduates ON users.userID = undergraduates.studentID 
            LEFT JOIN professors ON users.userID = professors.profID 
            LEFT JOIN secretary ON users.userID = secretary.secretaryID 
            WHERE users.acEmail = ? AND users.password = ?";



    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $username, $password);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $user_data = $result->fetch_assoc();

        // Set session variables after successful login
        $_SESSION['userID'] = $user_data['userID'];
        $_SESSION['firstName'] = $user_data['firstName'];
        $_SESSION['lastName'] = $user_data['lastName'];
        $_SESSION['acEmail'] = $user_data['acEmail'];
        $_SESSION['address'] = $user_data['address'];
        $_SESSION['phone_mobile'] = $user_data['phone_mobile'];
        $_SESSION['phone_home'] = $user_data['phone_home'];
        $_SESSION['AM'] = $user_data['AM'];
        $_SESSION['userType'] = $user_data['userType'];
        $_SESSION['userID'] = $user_data['userID'];
        $_SESSION['userType'] = $user_data['userType'];

        if ($user_data['userType'] == 'professor') {
            header("Location: ProfessorProfilePage.php");
        } elseif ($user_data['userType'] == 'undergraduate') {
            header("Location: StudentProfilePage.php");
        } else {
            header("Location: SecretaryProfilePage.php");
        }
        exit();
    } else {
        header("Location: LoginPage.php?error=invalid_credentials");
        exit();
    }

    $stmt->close();
    $conn->close();
}
?>