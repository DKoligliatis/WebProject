<?php
require 'config.php';
session_start();

$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$conn->set_charset("utf8mb4");

$userID = $_SESSION['userID']; // Retrieve user ID from session

$stmt = $conn->prepare("
    SELECT t.filePath, t.title
    FROM users u 
    INNER JOIN undergraduates ug ON u.userID = ug.studentID
    INNER JOIN diplomas d ON ug.studentID = d.studentID 
    INNER JOIN topics t ON d.topicID = t.topicID 
    WHERE u.userID = ?
");
$stmt->bind_param("i", $userID);

if ($stmt->execute()) {
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $fileData = $row['filePath']; // Binary data
        $fileName = $row['title'] . '.pdf'; // Use the topic title for the file name

        if (!empty($fileData)) {
            // Clear any previous output
            if (ob_get_level()) {
                ob_end_clean();
            }

            // Serve the file
            header('Content-Description: File Transfer');
            header('Content-Type: application/pdf');
            header('Content-Disposition: attachment; filename="' . $fileName . '"');
            header('Expires: 0');
            header('Cache-Control: must-revalidate');
            header('Pragma: public');
            header('Content-Length: ' . strlen($fileData));

            // Output the binary file content
            echo $fileData;
            exit;
        } else {
            echo "Error: No file data found.";
        }
    } else {
        echo "Error: No record found for this user.";
    }
} else {
    echo "Error: Query execution failed.";
}

$stmt->close();
$conn->close();
?>
