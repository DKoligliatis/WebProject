<?php
require 'config.php'; // Σύνδεση με τη βάση δεδομένων
session_start();

// Παίρνουμε το userID (profSupervID) από τη συνεδρία
$profSupervID = $_SESSION['userID'];

// Παίρνουμε το diplomaID από το POST
$diplomaID = $_POST['diplomaID'];

// Προετοιμάζουμε το query για να πάρουμε το tempFile για το δεδομένο diplomaID
$stmt = $conn->prepare("SELECT tempFile FROM diplomas WHERE diplomaID = ?");

$stmt->bind_param("i", $diplomaID); // Βάζουμε το diplomaID στην query

if ($stmt->execute()) {
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // Αν βρεθεί το αποτέλεσμα, παίρνουμε τα δεδομένα του αρχείου
        $row = $result->fetch_assoc();
        $fileData = $row['tempFile']; // Δεδομένα του αρχείου
        $fileName = 'diploma_' . $diplomaID . '.pdf'; // Χρησιμοποιούμε το diplomaID για το όνομα του αρχείου

        if (!empty($fileData)) {
            // Καθαρίζουμε οποιοδήποτε προηγούμενο output
            if (ob_get_level()) {
                ob_end_clean();
            }

            // Σερβίρουμε το αρχείο
            header('Content-Description: File Transfer');
            header('Content-Type: application/pdf');
            header('Content-Disposition: attachment; filename="' . $fileName . '"');
            header('Expires: 0');
            header('Cache-Control: must-revalidate');
            header('Pragma: public');
            header('Content-Length: ' . strlen($fileData));

            // Εξάγουμε τα δεδομένα του αρχείου
            echo $fileData;
            exit;
        } else {
            echo "Error: No draft file data found.";
        }
    } else {
        echo "Error: No diploma found under review for this professor.";
    }
} else {
    echo "Error: Query execution failed.";
}

$stmt->close();
$conn->close();
?>
