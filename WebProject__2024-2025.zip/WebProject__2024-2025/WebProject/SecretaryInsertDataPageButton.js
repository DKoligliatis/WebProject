document.getElementById("data-input").addEventListener("click", function() {
    window.location.href = 'SecretaryInsertDataPage.php';
});