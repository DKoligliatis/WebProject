<?php
require 'config.php'; // Σύνδεση με τη βάση δεδομένων
session_start();

// Παίρνουμε το userID (profSupervID) από τη συνεδρία
$profSupervID = $_SESSION['userID'];

if (isset($_POST['committeeID'])) {
    $committeeID = $_POST['committeeID'];

    // Prevent SQL Injection by using prepared statements
    $query = "SELECT grade FROM gradelog WHERE committeeID = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('i', $committeeID);
    $stmt->execute();
    $result = $stmt->get_result();

    // Fetch the grades and return them as a JSON response
    $grades = [];
    while ($row = $result->fetch_assoc()) {
        $grades[] = $row;
    }

    // Return the grades as JSON
    if (!empty($grades)) {
        echo json_encode(['status' => 'success', 'grades' => $grades]);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'No grades found']);
    }
    exit(); // Stop further processing of the page
}

if (isset($_POST['action']) && $_POST['action'] === 'fetchNotes' && isset($_POST['diplomaID'])) {
    $diplomaID = intval($_POST['diplomaID']);

    // Prevent SQL Injection with prepared statements
    $query = "SELECT noteText FROM diplomanotes WHERE diplomaID = ? AND profID = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('ii', $diplomaID,$profSupervID);
    $stmt->execute();
    $result = $stmt->get_result();

    $notes = [];
    while ($row = $result->fetch_assoc()) {
        $notes[] = $row['noteText'];
    }

    echo json_encode(['status' => 'success', 'notes' => $notes]);
    exit();
}
?>

<html>
<head>
<title>ΤΜΥΠ | Προβολή Διπλωματικών Εργασιών</title>
<link rel="icon" type="image/png" href="ceid_logo.png">
<link rel="stylesheet" href="ProfManageThesisPage.css">

</head>

<body>
<div class="upper-section">
    <a href="https://www.ceid.upatras.gr" target="_self">
        <img src="upatras_ceid_logo.png" alt="upatras_ceid_logo">
    </a>
    <button class="logout-button"onclick="window.location.href='logout.php'">Έξοδος</button>
</div>

<div class="container">  
    <div class="main-menu">   
        <button class="menu-item" id="profile">Προφίλ </button>
        <button class="menu-item" id="view-and-create-thesis">Προβολή και Δημιουργία <br>Θεμάτων προς Ανάθεση</button>
        <button class="menu-item" id="assign-thesis">Αρχική Ανάθεση Θέματος <br>σε Φοιτητή </button>
        <button class="menu-item" id="view-list-thesis">Προβολή Λίστας <br>Διπλωματικών</button>
        <button class="menu-item" id="view-requests-3">Προβολή Προσκλήσεων <br> Συμμετοχής σε Τριμελή</button>
        <button class="menu-item" id="view-sattistics">Προβολή Στατιστικών</button>
        <button class="menu-item" id="manage-thesis">Διαχείριση Διπλωματικών <br>Εργασιών</button>
    </div>  

    <div class="content">
        <div class="thesis-table">
            <h2>Προβολή Διπλωματικών Εργασιών ανά Κατάσταση </h2>

            <?php
            // Χρησιμοποιούμε την υπάρχουσα σύνδεση από το config.php
            global $conn;

            $currentDate = new DateTime();

            // Updated query based on the requirements
$query1 = "SELECT 
    d.diplomaID AS diplomaID,
    t.title AS topicTitle,
    t.topicID AS topicID,
    d.status AS status,
    c.committeeID AS comID,
    d.Grade AS grade,
    d.startDate AS startDate,
    d.tempFile AS tempFile,
    CONCAT(sup_user.firstName, ' ', sup_user.lastName) AS supervisorName,
    CONCAT(mem1_user.firstName, ' ', mem1_user.lastName) AS member1Name,
    CONCAT(mem2_user.firstName, ' ', mem2_user.lastName) AS member2Name,
    CONCAT(student_user.firstName, ' ', student_user.lastName) AS studentName 
FROM 
    diplomas d
JOIN 
    committees c ON d.committeeID = c.committeeID
JOIN 
    topics t ON d.topicID = t.topicID
JOIN 
    professors sup ON c.supervisorID = sup.profID
JOIN 
    users sup_user ON sup.profID = sup_user.userID
JOIN 
    professors mem1 ON c.member1ID = mem1.profID
JOIN 
    users mem1_user ON mem1.profID = mem1_user.userID
JOIN 
    professors mem2 ON c.member2ID = mem2.profID
JOIN 
    users mem2_user ON mem2.profID = mem2_user.userID
JOIN 
    undergraduates u ON d.studentID = u.studentID -- Join with undergraduates table
JOIN 
    users student_user ON u.studentID = student_user.userID -- Join with users table to get student name
WHERE 
    (c.member1ID = $profSupervID OR c.member2ID = $profSupervID OR c.supervisorID = $profSupervID);

";

            // Εκτέλεση του query
            $result1 = mysqli_query($conn, $query1);

            // Αν υπάρχουν αποτελέσματα, τα προβάλλουμε σε πίνακα
            if (mysqli_num_rows($result1) > 0) {
                echo "<table border='1'>";
                echo "<tr>
                        <th>Diploma ID</th>
                        <th>Topic ID</th>
                        <th>ID Τριμελούς</th>
                        <th>Τίτλος Θέματος</th>
                        <th>Ημερομηνία Έναρξης</th>
                        <th>Κατάσταση</th>
                        <th>Όνομα Φοιτητή</th>
                        <th>Όνομα Επιβλέποντα</th>
                        <th>Όνομα Μέλους 1</th>
                        <th>Όνομα Μέλους 2</th>
                        <th>Βαθμός</th>                        
                        <th>Ενέργεια</th>
                    </tr>";
                
                while ($row = mysqli_fetch_assoc($result1)) {
                    
                    $startDate = new DateTime($row['startDate']);
                    $interval = $currentDate->diff($startDate);

                    echo "<tr>";
                    echo "<td>" . htmlspecialchars($row['diplomaID']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['topicID']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['comID']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['topicTitle']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['startDate']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['status']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['studentName']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['supervisorName']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['member1Name']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['member2Name']) . "</td>";  
                    echo "<td>" . htmlspecialchars($row['grade']) . "</td>";    
                                       
                    //echo "<td>" . htmlspecialchars($row['invitationDate']) . "</td>";
                    echo "<td>";                
                        if ($row['status'] === 'Temporarily Assigned') {
                            echo "<form action='CancelCommittee.php' method='POST'>
                                <input type='hidden' name='committeeID' value='" . htmlspecialchars($row['comID']) . "'>
                                <input type='hidden' name='topicID' value='" . htmlspecialchars($row['topicID']) . "'>
                                <button type='submit' class='cancel-button'>Ακύρωση Τριμελούς</button>
                            </form>";
                        }elseif ($interval->y >= 2 && $row['status'] !== 'Cancelled') {
                            // Automatically cancel the diploma if more than 2 years have passed
                            $updateQuery = "UPDATE diplomas SET status = 'Cancelled' WHERE diplomaID = ?";
                            $stmt = $conn->prepare($updateQuery);
                            $stmt->bind_param('i', $row['diplomaID']);
                            $stmt->execute();
                            echo "<script>alert('H κατάσταση της διπλωματική με ID  " . $row['diplomaID'] . "άλλαξε σε Ακυρωμένη επειδή πέρασαν 2 έτη 5.');</script>";
                            
                        } elseif ($row['status'] === 'In Progress') {
                            echo "<form action='#' method='POST' id='addNoteForm" . $row['comID'] . "' style='display:none;'> 
                                    <textarea name='noteText' id='noteText" . $row['comID'] . "' maxlength='300' placeholder='Enter your note here'></textarea><br>
                                    <button type='button' class='save-note-button' onclick='saveNote(" . $row['diplomaID'] . ", " . $row['comID'] . ")'>Αποθήκευση Σημείωσης</button>
                                </form>";
                            echo "<button class='add-note-button' onclick='toggleNoteInput(" . $row['comID'] . ")'>Προσθήκη Σημείωσης</button>";
                            
                            echo "<form action='changeStatus.php' method='POST'>
                                <input type='hidden' name='topicID' value='" . htmlspecialchars($row['topicID']) . "'>
                                <button type='submit' class='change-status-button'>Αλλαγή σε Υπό Εξέταση</button>
                                </form>";
                            
                            echo "<button class='view-notes-button' onclick='viewNotes(" . $row['diplomaID'] . ")'>Προβολή Σημειώσεων</button>";
                            
                            echo '
                                    <div id="notesModal" style="display:none; position:fixed; top:0; left:0; width:100%; height:100%; background-color:rgba(0,0,0,0.5); z-index:1000;">
                                        <div style="margin: 15% auto; padding: 20px; background-color: white; width: 50%; border-radius: 5px;">
                                            <h3>Σημειώσεις</h3>
                                            <div id="notesContent"></div>
                                            <button onclick="closeNotesModal()">Κλείσιμο</button>
                                        </div>
                                    </div>';
                                        
                            echo "<form action='cancelDiploma.php' method='POST' id='cancelDiplomaForm'>
                                <input type='hidden' name='topicID' value='" . htmlspecialchars($row['topicID']) . "'>
                                
                                <!-- Button to trigger visibility of the text areas -->
                                <button type='button' class='cancel-diploma-button' id='showCancelFieldsBtn'>Ακύρωση Διπλωματικής</button>
                        
                                <!-- Hidden text areas that will show up when the button is clicked -->
                                <div id='cancelFields' style='display: none;'>
                                    <label for='cancelReason" . $row['comID'] . "'>Λόγος Ακύρωσης:</label>
                                    <textarea name='cancelReason' id='cancelReason" . $row['comID'] . "' maxlength='300' placeholder='Πληκτρολογήστε τον λόγο ακύρωσης'></textarea><br>
                                    
                                    <label for='assemblyYear" . $row['comID'] . "'>Έτος Συγκρότησης:</label>
                                    <input type='text' name='assemblyYear' id='assemblyYear" . $row['comID'] . "' placeholder='Πληκτρολογήστε το έτος' /><br>
                                    
                                    <label for='assemblyNumber" . $row['comID'] . "'>Αριθμός Συγκρότησης:</label>
                                    <input type='text' name='assemblyNumber' id='assemblyNumber" . $row['comID'] . "' placeholder='Πληκτρολογήστε τον αριθμό' /><br>
                        
                                    <button type='submit' class='submit-diploma-button'>Υποβολή Ακύρωσης</button>
                                </div>
                            </form>";                       
                        } elseif ($row['status'] === 'Under Review'){
                            echo "<form action='submitGrade.php' method='POST' id='insertGradeForm" . htmlspecialchars($row['comID']) . "' style='display: none;'>
        <label for='gradeInput" . htmlspecialchars($row['comID']) . "'>Βαθμός (1-10):</label>
        <input type='number' name='grade' id='gradeInput" . htmlspecialchars($row['comID']) . "' min='1' max='10' step='0.1' required>
        <input type='hidden' name='committeeID' value='" . htmlspecialchars($row['comID']) . "'>
        <input type='hidden' name='profID' value='" . htmlspecialchars($_SESSION['userID']) . "'>
        <button type='submit' class='submit-grade-button'>Υποβολή</button>
    </form>
    <div id='gradeMessage" . htmlspecialchars($row['comID']) . "' style='display: none; color: green; margin-top: 5px;'></div>
    <button class='insert-grade-button' onclick='toggleGradeInput(" . htmlspecialchars($row['comID']) . ")'>Προσθήκη Βαθμού</button>";

// Add "View Grades" button
echo "<button class='view-grades-button' onclick='viewGrades(" . htmlspecialchars($row['comID']) . ")'>Προβολή Βαθμολογιών</button>";
echo "<div id='gradesContainer" . htmlspecialchars($row['comID']) . "' style='display:none;'></div>";

echo "<form action='downloadTempDip.php' method='POST'>
        <input type='hidden' name='diplomaID' value='" . htmlspecialchars($row['diplomaID']) . "'>
        <button type='submit' id='downloadTempDip'>Κατέβασμα Προσωριμής<br>Διπλωματικής</button>
    </form>";
                         
                        }
                    echo "</td>";
                    echo "</tr>";
                               
                }
                echo "</table>";
            }else {
                echo "Δεν βρέθηκαν αποτελέσματα.";
            }
            ?>
        </div>
    </div>
</div>

<script>
function toggleNoteInput(comID) {
const form = document.getElementById('addNoteForm' + comID);
form.style.display = form.style.display === 'none' ? 'block' : 'none';
}


function saveNote(diplomaID, comID) {
    const noteText = document.getElementById('noteText' + comID).value;
    const formData = new FormData();
    formData.append('noteText', noteText);
    formData.append('diplomaID', diplomaID); // Use diplomaID instead of topicID

    fetch('addNote.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.text())
    .then(data => {
        alert(data); // Optionally handle the response, show success/failure message
        
        // Hide the text input area and Save button after successful save
        const form = document.getElementById('addNoteForm' + comID);
        form.style.display = 'none';
    })
    .catch(error => console.error('Error:', error));
}


function changeStatus(topicID) {
const formData = new FormData();
formData.append('topicID', topicID);

fetch('changeStatus.php', {
    method: 'POST',
    body: formData
})
.then(response => response.text())
.then(data => {
    alert(data); // Show the response message in an alert

    // Optionally, hide the Change Status button or perform other actions after success
    const statusButton = document.getElementById('change-status-button-' + topicID);
    statusButton.style.display = 'none'; // Hide the button after successful status change
})
.catch(error => console.error('Error:', error));
}

// Attach the event listener to the button for each topic
document.querySelectorAll('.change-status-button').forEach(button => {
button.addEventListener('click', function() {
    const topicID = this.dataset.topicId; // Get the topicID from the data attribute
    changeStatus(topicID);
});
});

function toggleCancelForm(comID) {
const form = document.getElementById('cancelForm' + comID);
form.style.display = form.style.display === 'none' ? 'block' : 'none';
}

document.getElementById('showCancelFieldsBtn').addEventListener('click', function() {
var cancelFields = document.getElementById('cancelFields');
if (cancelFields.style.display === 'none') {
    cancelFields.style.display = 'block'; // Show the fields
} else {
    cancelFields.style.display = 'none'; // Hide the fields if clicked again
}
});
function toggleGradeInput(comID) {
    const form = document.getElementById('insertGradeForm' + comID);
    form.style.display = form.style.display === 'none' ? 'block' : 'none';
}

function submitGrade(comID) {
    const form = document.getElementById('insertGradeForm' + comID);
    const formData = new FormData(form);

    fetch('submitGrade.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        // Target the modal and message element
        const modal = document.getElementById('messageModal');
        const messageElement = document.getElementById('modalMessage');

        if (data.status === 'success') {
            // Show success message in the modal
            modal.style.display = 'flex';
            messageElement.textContent = "localhost says: " + data.message;
        } else {
            // Show error message in the modal
            modal.style.display = 'flex';
            messageElement.textContent = "localhost says: " + data.message;
        }

        // Optionally, add a delay before redirecting
        setTimeout(function() {
            // Redirect to ProfManageThesisPage.php after closing the modal or delay
            window.location.href = 'ProfManageThesisPage.php';
        }, 2000); // 2000ms delay before redirect (adjust as needed)
    })
    .catch(error => console.error('Error:', error));
}

function viewGrades(comID) {
    const gradesContainer = document.getElementById('gradesContainer' + comID);
    
    // Toggle visibility
    if (gradesContainer.style.display === 'none') {
        // If grades are hidden, fetch and display them
        const formData = new FormData();
        formData.append('committeeID', comID);  // Send committeeID to the server

        fetch('ProfManageThesisPage.php', {  // Send the request to the same PHP file
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if (data.status === 'success') {
                // Create a container for displaying the grades
                let gradesDisplay = '<ul>';
                data.grades.forEach(grade => {
                    gradesDisplay += `<li>Grade: ${grade.grade}</li>`;
                });
                gradesDisplay += '</ul>';

                // Display the grades in the container
                gradesContainer.innerHTML = gradesDisplay;
                gradesContainer.style.display = 'block';  // Show the grades container
            } else {
                alert('No grades found for this committee.');
            }
        })
        .catch(error => console.error('Error:', error));
    } else {
        // If grades are visible, hide them
        gradesContainer.style.display = 'none';
    }
}


function viewNotes(diplomaID) {
    const modal = document.getElementById('notesModal');
    const notesContent = document.getElementById('notesContent');

    // Show the modal
    modal.style.display = 'block';

    // Fetch notes using AJAX
    const formData = new FormData();
    formData.append('action', 'fetchNotes');
    formData.append('diplomaID', diplomaID);

    fetch('ProfManageThesisPage.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.status === 'success') {
            // Populate the modal with notes
            if (data.notes.length > 0) {
                notesContent.innerHTML = '<ul>' + data.notes.map(note => `<li>${note}</li>`).join('') + '</ul>';
            } else {
                notesContent.textContent = 'Δεν βρέθηκαν σημειώσεις.';
            }
        } else {
            notesContent.textContent = 'Σφάλμα κατά την ανάκτηση σημειώσεων.';
        }
    })
    .catch(error => {
        notesContent.textContent = 'Σφάλμα κατά την ανάκτηση σημειώσεων.';
        console.error('Error:', error);
    });
}

function closeNotesModal() {
    const modal = document.getElementById('notesModal');
    modal.style.display = 'none';
    document.getElementById('notesContent').innerHTML = ''; // Clear content
}

</script>
<script src="LogoutButton.js"></script>
<script src="editButtonProf.js"></script> 
<script src="ProfViewCreateThesisPageButton.js"></script>
<script src="ProfAssignThesisPageButton.js"></script>
<script src="ProfViewListThesisPageButton.js"></script> 
<script src="ProfManageThesisPageButton.js"></script>
<script src="ProfessorProfileButton.js"></script>
<script src="ProfRequests3.js"></script>
<script src="ProfStatistics.js"></script>

</body>
</html>