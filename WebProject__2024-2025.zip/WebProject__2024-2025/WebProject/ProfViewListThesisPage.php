<?php
require 'config.php';
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'];

    if ($action === 'getTheses') {
        $status = $_POST['status'] ?? null;
        $role = $_POST['role'] ?? null;
        $userID = $_SESSION['userID'];

        // Combined query to get thesis data along with committee members
        $sql = "SELECT d.diplomaID, t.title, t.description, t.status AS topicStatus, 
                        CONCAT(u.firstName, ' ', u.lastName) AS studentName, un.AM as studentAM,
                        c.supervisorID, c.member1ID, c.member2ID, d.status AS diplomaStatus, d.Grade,
                        c.committeeID AS comID,
                        u1.firstName AS supervisorFirstName, u1.lastName AS supervisorLastName,
                        u2.firstName AS member1FirstName, u2.lastName AS member1LastName,
                        u3.firstName AS member2FirstName, u3.lastName AS member2LastName,
                        d.nhmerthsLink AS nhmerthsLink
                FROM diplomas d
                JOIN topics t ON d.topicID = t.topicID
                JOIN users u ON d.studentID = u.userID
                JOIN undergraduates un ON un.studentId = u.userID
                JOIN committees c ON d.committeeID = c.committeeID
                LEFT JOIN users u1 ON u1.userID = c.supervisorID
                LEFT JOIN users u2 ON u2.userID = c.member1ID
                LEFT JOIN users u3 ON u3.userID = c.member2ID
                WHERE (c.supervisorID = ? OR c.member1ID = ? OR c.member2ID = ?)";

        $params = [$userID, $userID, $userID];
        $types = "iii";

        if ($status) {
            $sql .= " AND d.status = ?";
            $params[] = $status;
            $types .= "s";
        }

        if ($role === 'supervisor') {
            $sql .= " AND c.supervisorID = ?";
            $params[] = $userID;
            $types .= "i";
        } elseif ($role === 'member') {
            $sql .= " AND (c.member1ID = ? OR c.member2ID = ?)";
            $params[] = $userID;
            $params[] = $userID;
            $types .= "ii";
        }

        $stmt = $conn->prepare($sql);
        $stmt->bind_param($types, ...$params);
        $stmt->execute();
        $result = $stmt->get_result();

        $theses = [];
        while ($row = $result->fetch_assoc()) {
            $theses[] = [
                'diplomaID' => $row['diplomaID'],
                'title' => $row['title'],
                'description' => $row['description'],
                'studentName' => $row['studentName'],
                'studentAM' => $row['studentAM'],
                'diplomaStatus' => $row['diplomaStatus'],
                
                'supervisorName' => $row['supervisorFirstName'] . ' ' . $row['supervisorLastName'],
                'Grade' => $row['Grade'],
                'member1Name' => $row['member1FirstName'] . ' ' . $row['member1LastName'],
                'member2Name' => $row['member2FirstName'] . ' ' . $row['member2LastName'],
                'nhmerthsLink' => $row['nhmerthsLink'],
            ];
        }

        echo json_encode($theses);
        exit();
    } elseif ($action === 'exportTheses') {
        $format = $_POST['format']; // CSV or JSON
        $data = json_decode($_POST['data'], true);

        if ($format === 'csv') {
            header('Content-Type: text/csv');
            header('Content-Disposition: attachment; filename="theses.csv"');

            $output = fopen('php://output', 'w');
            fputcsv($output, array_keys($data[0])); // Header row
            foreach ($data as $row) {
                fputcsv($output, $row);
            }
            fclose($output);
            exit();
        } elseif ($format === 'json') {
            header('Content-Type: application/json');
            header('Content-Disposition: attachment; filename="theses.json"');
            echo json_encode($data);
            exit();
        }
    } elseif ($action === 'getStatusChanges') {
        $diplomaID = $_POST['diplomaID'];

        $sql = "SELECT statusChangedTo, dateOfChange FROM diplstatuslog WHERE diplID = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $diplomaID);
        $stmt->execute();
        $result = $stmt->get_result();

        $statusChanges = [];
        while ($row = $result->fetch_assoc()) {
            $statusChanges[] = $row;
        }

        echo json_encode($statusChanges);
        exit();
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>ΤΜΥΠ | Προβολή Διπλωματικών Εργασιών</title>
    <link rel="icon" type="image/png" href="ceid_logo.png">
    <link rel="stylesheet" href="ProfViewListThesisPage.css">
</head>
<body>
    <div class="upper-section">
        <a href="https://www.ceid.upatras.gr" target="_self">
            <img src="upatras_ceid_logo.png" alt="upatras_ceid_logo">
        </a>
        <button class="logout-button" onclick="window.location.href='logout.php'">Έξοδος</button>
    </div>
    
    <div class="container">  
        <div class="main-menu">   
            <button class="menu-item" id="profile">Προφίλ</button>
            <button class="menu-item" id="view-and-create-thesis">Προβολή και Δημιουργία <br>Θεμάτων προς Ανάθεση</button>  
            <button class="menu-item" id="assign-thesis">Αρχική Ανάθεση Θέματος <br>σε Φοιτητή</button>  
            <button class="menu-item" id="view-list-thesis">Προβολή Λίστας <br>Διπλωματικών</button>
            <button class="menu-item" id="view-requests-3">Προβολή Προσκλήσεων <br> Συμμετοχής σε Τριμελή</button>
            <button class="menu-item" id="view-sattistics">Προβολή Στατιστικών</button>
            <button class="menu-item" id="manage-thesis">Διαχείριση Διπλωματικών <br>Εργασιών</button>
        </div> 

    <div class="content">
        <h1>Λίστα Διπλωματικών</h1>

        <!-- Φόρμα Φιλτραρίσματος -->
        <div>
            <label for="status-filter">Κατάσταση:</label>
            <select id="status-filter" style=" width: 200px; height: 40px; padding: 5px; border-radius: 5px; background-color: #f9f9f9; font-size: medium; color: #000000; cursor: pointer;">
                <option value="">Όλες</option>
                <option value="Temporarily Assigned">Υπό Ανάθεση</option>
                <option value="In Progress">Ενεργή</option>
                <option value="Completed">Περατωμένη</option>
                <option value="Cancelled">Ακυρωμένη</option>
            </select>

            <label for="role-filter">Ρόλος:</label>
            <select id="role-filter" style="width: 200px; height: 40px; padding: 5px; border-radius: 5px; background-color: #f9f9f9; font-size: medium; color: #000000; cursor: pointer;">
                <option value="">Όλοι</option>
                <option value="supervisor">Επιβλέπων</option>
                <option value="member">Μέλος Τριμελούς</option>
            </select>

            <button id="filter-button" style="background-color: #1d50b6; color: #ffffff; border-radius: 10px; font-size: medium; padding: 10px; cursor: pointer;">Φιλτράρισμα</button>
        </div>
        <br>
        <!-- Λίστα Διπλωματικών -->
        <table id="theses-table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Τίτλος</th>
                    <th>Περιγραφή</th>
                    <th>Φοιτητής</th>
                    <th>ΑΜ Φοιτητή</th>
                    <th>Κατάσταση</th>
                    <th>Βαθμός</th>
                    <th>Επιβλέπων</th>
                    
                    <th>Μέλος 1</th>
                    <th>Μέλος 2</th>
                    <th>Σύνδεσμος<br>Νημερτή</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <!-- Δεδομένα θα φορτωθούν δυναμικά -->
            </tbody>
        </table>
        <br>
        <!-- Εξαγωγή -->
        <div>
            <button id="export-csv" style="background-color: #1d50b6; color: #ffffff; border-radius: 10px; font-size: medium; padding: 10px; cursor: pointer;">Εξαγωγή σε CSV</button>
            <button id="export-json" style="background-color: #1d50b6; color: #ffffff; border-radius: 10px; font-size: medium; padding: 10px; cursor: pointer;">Εξαγωγή σε JSON</button>
        </div>

        <div id="status-changes-container" style="display: none;">
            <!-- Content will be dynamically inserted here -->
        </div>
    </div>

    <script src="script.js"></script>
    <script src="LogoutButton.js"></script>
    <script src="ProfessorProfileButton.js"></script>
    <script src="ProfViewCreateThesisPageButton.js"></script>
    <script src="ProfAssignThesisPageButton.js"></script>
    <script src="ProfViewListThesisPageButton.js"></script>
    <script src="ProfManageThesisPageButton.js"></script>
    <script src="ProfRequests3.js"></script>
    <script src="ProfStatistics.js"></script>
</body>
</html>


<script>

document.getElementById('filter-button').addEventListener('click', () => {
    const status = document.getElementById('status-filter').value;
    const role = document.getElementById('role-filter').value;

    fetch('', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: `action=getTheses&status=${encodeURIComponent(status)}&role=${encodeURIComponent(role)}`
    })
        .then(response => response.json())
        .then(data => {
            const tableBody = document.querySelector('#theses-table tbody');
            tableBody.innerHTML = '';

            data.forEach(thesis => {
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td>${thesis.diplomaID}</td>
                    <td>${thesis.title}</td>
                    <td>${thesis.description}</td>
                    <td>${thesis.studentName}</td>
                    <td>${thesis.studentAM}</td>
                    <td>${thesis.diplomaStatus}</td>
                    
                    <td>${thesis.Grade ?? '-'}</td>
                    <td>${thesis.supervisorName}</td>
                    <td>${thesis.member1Name}</td>
                    <td>${thesis.member2Name}</td>
                    <td>${thesis.nhmerthsLink}</td>
                    <td><button class="view-changes-btn">Προβολή Αλλαγών</button></td>
                `;
                tableBody.appendChild(row);
            });
        });
});

document.querySelector('#theses-table').addEventListener('click', (e) => {
    if (e.target.classList.contains('view-changes-btn')) {
        const diplomaID = e.target.closest('tr').querySelector('td').textContent;

        fetch('', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: `action=getStatusChanges&diplomaID=${encodeURIComponent(diplomaID)}`
        })
            .then(response => response.json())
            .then(data => {
                const modalContent = data.map(change => `
                    <tr>
                        <td>${change.statusChangedTo}</td>
                        <td>${change.dateOfChange}</td>
                    </tr>
                `).join('');

                const modal = document.createElement('div');
                modal.classList.add('modal');
                modal.innerHTML = `
                    <div class="modal-content">
                        <h2>Αλλαγές Κατάστασης</h2>
                        <button class="close-btn">Κλείσιμο</button>
                        <table>
                            <thead>
                                <tr>
                                    <th>Νέα Κατάσταση</th>
                                    <th>Ημερομηνία Αλλαγής</th>
                                </tr>
                            </thead>
                            <tbody>
                                ${modalContent}
                            </tbody>
                        </table>
                    </div>
                `;
                document.body.appendChild(modal);

                // Close modal
                modal.querySelector('.close-btn').addEventListener('click', () => {
                    modal.remove();
                });
            });
    }
});


document.getElementById('export-csv').addEventListener('click', () => {
    exportData('csv');
});

document.getElementById('export-json').addEventListener('click', () => {
    exportData('json');
});

function exportData(format) {
    const tableRows = Array.from(document.querySelectorAll('#theses-table tbody tr'));
    const data = tableRows.map(row => {
        const cells = row.querySelectorAll('td');
        return {
            diplomaID: cells[0].textContent,
            title: cells[1].textContent,
            description: cells[2].textContent,
            studentName: cells[3].textContent,
            studentAM: cells[4].textContent,
            diplomaStatus: cells[5].textContent,
            role: cells[6].textContent,
            Grade: cells[7].textContent,
            Member1: cells[8].textContent,
            Member2: cells[9].textContent,
            NhmerthsLink: cells[10].textContent
        };
    });

    fetch('', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: `action=exportTheses&format=${format}&data=${encodeURIComponent(JSON.stringify(data))}`
    })
        .then(response => response.blob())
        .then(blob => {
            const link = document.createElement('a');
            link.href = URL.createObjectURL(blob);
            link.download = `theses.${format}`;
            link.click();
        });
}
</script>