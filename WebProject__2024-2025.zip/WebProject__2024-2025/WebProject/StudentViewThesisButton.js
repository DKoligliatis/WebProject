document.getElementById("view-thesis").addEventListener("click", function() {
    window.location.href = 'StudentViewThesis.php';
});