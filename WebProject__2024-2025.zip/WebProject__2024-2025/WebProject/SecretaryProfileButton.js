document.getElementById("profile").addEventListener("click", function() {
    window.location.href = 'SecretaryProfilePage.php';
});