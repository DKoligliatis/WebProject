document.getElementById("view-list-thesis").addEventListener("click", function() {
    window.location.href = 'ProfViewListThesisPage.php';
});