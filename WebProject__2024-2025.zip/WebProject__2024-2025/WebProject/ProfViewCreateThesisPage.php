<?php
require 'config.php'; // Σύνδεση με τη βάση δεδομένων
session_start();
?>
<html><head>
        <!-- Τίτλος της σελίδας που εμφανίζεται στην καρτέλα -->
        <title>ΤΜΥΠ | Προβολή και Δημιουργία Διπλωματικών Εργασιών</title>
        
        <!-- Ορισμός της εικόνα που εμφανίζεται στην καρτέλα -->
        <link rel="icon" type="image/png" href="ceid_logo.png">
        
        <!-- Σύνδεση με το  αρχείο CSS για την εμφάνιση της σελίδας -->
        <link rel="stylesheet" href="ProfViewCreateThesisPage.css">

    </head>

    <body>
        <!-- Άνω τμήμα της σελίδας με το λογότυπο και το κουμπί εξόδου -->
        <div class="upper-section">
			<!-- Σύνδεσμος για να επιστρέψει ο χρήστης στην ιστοσελίδα του τμήματος -->
			<a href="https://www.ceid.upatras.gr" target="_self">
				<!-- Εικόνα του λογότυπου του τμήματος -->
				<img src="upatras_ceid_logo.png" alt="upatras_ceid_logo">
			</a>

			<!-- Κουμπί εξόδου για αποσύνδεση από την πλατφόρμα -->
			<button class="logout-button"onclick="window.location.href='logout.php'">Έξοδος</button>
		</div>
		
        <!-- Κύριο περιεχόμενο της σελίδας -->
        <div class="container">  
            <div class="main-menu">   
                <!-- Κουμπί για το προφίλ του καθηγητή -->
                <button class="menu-item" id="profile">Προφίλ </button>
                
                <!-- Κουμπί για την προβολή και δημιουργία θεμάτων προς ανάθεση -->
                <button class="menu-item" id="view-and-create-thesis">Προβολή και Δημιουργία <br>Θεμάτων προς Ανάθεση</button>  
                
                <!-- Κουμπί για την αρχική ανάθεση θέματος σε φοιτητή -->
                <button class="menu-item" id="assign-thesis">Αρχική Ανάθεση Θέματος <br>σε Φοιτητή </button>  
                
                <!-- Κουμπί για την προβολή λίστας διπλωματικών εργασιών -->
                <button class="menu-item" id="view-list-thesis">Προβολή Λίστας <br>Διπλωματικών</button>
                <button class="menu-item" id="view-requests-3">Προβολή Προσκλήσεων <br> Συμμετοχής σε Τριμελή</button>
              
                <!-- Κουμπί για την προβολή στατιστικών -->
                <button class="menu-item" id="view-sattistics">Προβολή Στατιστικών</button>
                
                <!-- Κουμπί για τη διαχείριση των διπλωματικών εργασιών -->
                <button class="menu-item" id="manage-thesis">Διαχείριση Διπλωματικών <br>Εργασιών</button>
            </div>  
            
            <div class="content">
                <button id="create-thesis">Δημιουργία Διπλωματικής Εργασίας</button>
                <button id="view-thesis">Προβολή Διπλωματικών Εργασιών</button>
            </div>
        </div>
        
        <!-- Σύνδεση με το αρχείο JavaScript για τη λειτουργία των κουμπιών -->
        <script src="LogoutButton.js"></script>
        <script src="ProfessorProfileButton.js"></script> 
        <script src="ProfViewThesisPageButton.js"></script>
        <script src="ProfCreateThesisPageButton.js"></script>
        <script src="ProfAssignThesisPageButton.js"></script>
        <script src="ProfViewListThesisPageButton.js"></script>  
        <script src="ProfManageThesisPageButton.js"></script> 
        <script src="ProfRequests3.js"></script>
        <script src="ProfStatistics.js"></script>
        <script src="ProfStatistics.js"></script>
    </body>
</html>