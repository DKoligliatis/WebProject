document.getElementById("assign-thesis").addEventListener("click", function() {
    window.location.href = 'ProfAssignThesisPage.php';
});