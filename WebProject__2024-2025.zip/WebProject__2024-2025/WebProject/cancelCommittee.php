<?php
require 'config.php'; // Σύνδεση με τη βάση δεδομένων
session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Παίρνουμε τα committeeID και topicID από το POST
    $committeeID = intval($_POST['committeeID']);
    $topicID = intval($_POST['topicID']);

    // Ελέγχουμε αν τα IDs είναι έγκυρα
    if ($committeeID > 0 && $topicID > 0) {
        // Ξεκινάμε συναλλαγή για να εξασφαλίσουμε την ατομικότητα των αλλαγών
        $conn->begin_transaction();

        try {
            // 1. Ενημέρωση του status στον πίνακα topics σε "Cancelled"
            $updateTopicQuery = "UPDATE topics SET status = 'Cancelled' WHERE topicID = ?";
            $stmt1 = $conn->prepare($updateTopicQuery);
            $stmt1->bind_param("i", $topicID);
            $stmt1->execute();

            // 2. Διαγραφή από τον πίνακα committees
            $deleteCommitteeQuery = "DELETE FROM committees WHERE committeeID = ?";
            $stmt2 = $conn->prepare($deleteCommitteeQuery);
            $stmt2->bind_param("i", $committeeID);
            $stmt2->execute();

            // 3. Διαγραφή από τον πίνακα reqlist
            $deleteReqlistQuery = "DELETE FROM reqlist WHERE commiteeReqID = ?";
            $stmt3 = $conn->prepare($deleteReqlistQuery);
            $stmt3->bind_param("i", $committeeID);
            $stmt3->execute();

            // Επιβεβαίωση των αλλαγών
            $conn->commit();

            // Επιστροφή στη σελίδα με επιτυχία
            header("Location: ProfManageThesisPage.php?success=1");
        } catch (Exception $e) {
            // Σε περίπτωση σφάλματος, κάνουμε rollback
            $conn->rollback();

            // Επιστροφή με μήνυμα σφάλματος
            header("Location: ProfManageThesisPage.php?error=1");
        }

        // Κλείσιμο των statements
        $stmt1->close();
        $stmt2->close();
        $stmt3->close();
    } else {
        // Αν τα IDs δεν είναι έγκυρα
        header("Location: Prof6.php?error=1");
    }
}
$conn->close();
?>