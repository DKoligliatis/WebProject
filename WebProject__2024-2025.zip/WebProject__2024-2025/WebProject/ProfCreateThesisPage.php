<?php
require 'config.php'; // Σύνδεση με τη βάση δεδομένων
session_start();
?>

<!DOCTYPE html>
<html>
    <head>
        <!-- Τίτλος της σελίδας που εμφανίζεται στην καρτέλα -->
        <title>ΤΜΥΠ | Δημιουργία Διπλωματικής Εργασίας</title>
        
        <!-- Ορισμός της εικόνα που εμφανίζεται στην καρτέλα -->
        <link rel="icon" type="image/png" href="ceid_logo.png">
        
        <!-- Σύνδεση με το  αρχείο CSS για την εμφάνιση της σελίδας -->
        <link rel="stylesheet" href="ProfCreateThesisPage.css">

    </head>

    <body>
        <!-- Άνω τμήμα της σελίδας με το λογότυπο και το κουμπί εξόδου -->
        <div class="upper-section">
			<!-- Σύνδεσμος για να επιστρέψει ο χρήστης στην ιστοσελίδα του τμήματος -->
			<a href="https://www.ceid.upatras.gr" target="_self">
				<!-- Εικόνα του λογότυπου του τμήματος -->
				<img src="upatras_ceid_logo.png" alt="upatras_ceid_logo">
			</a>

			<!-- Κουμπί εξόδου για αποσύνδεση από την πλατφόρμα -->
			<button class="logout-button"onclick="window.location.href='logout.php'">Έξοδος</button>
		</div>
		
        <!-- Κύριο περιεχόμενο της σελίδας -->
        <div class="container">  
            <div class="main-menu">   
                <!-- Κουμπί για το προφίλ του καθηγητή -->
                <button class="menu-item" id="profile">Προφίλ </button>
                
                <!-- Κουμπί για την προβολή και δημιουργία θεμάτων προς ανάθεση -->
                <button class="menu-item" id="view-and-create-thesis">Προβολή και Δημιουργία <br>Θεμάτων προς Ανάθεση</button>  
                
                <!-- Κουμπί για την αρχική ανάθεση θέματος σε φοιτητή -->
                <button class="menu-item" id="assign-thesis">Αρχική Ανάθεση Θέματος <br>σε Φοιτητή </button>  
                
                <!-- Κουμπί για την προβολή λίστας διπλωματικών εργασιών -->
                <button class="menu-item" id="view-list-thesis">Προβολή Λίστας <br>Διπλωματικών</button>
                
                <!-- Κουμπί για την προβολή προσκλήσεων συμμετοχής σε τριμελή επιτροπή -->
                <button class="menu-item" id="view-requests-3">Προβολή Προσκλήσεων <br>Συμμετοχής σε Τριμελή</button>
                
                <!-- Κουμπί για την προβολή στατιστικών -->
                <button class="menu-item" id="view-sattistics">Προβολή Στατιστικών</button>
                
                <!-- Κουμπί για τη διαχείριση των διπλωματικών εργασιών -->
                <button class="menu-item" id="manage-thesis">Διαχείριση Διπλωματικών <br>Εργασιών</button>
            </div>  
            
            <div class="content">
                <div class="container">
                    <h1>Δημιουργία Νέου Θέματος</h1>
                    <form id="create-topic-form" method="post" action="createTopic.php" enctype="multipart/form-data">
                        <label for="title">Τίτλος Θέματος:</label>
                        <input type="text" id="title" name="title" required>

                        <label for="description">Περιγραφή:</label>
                        <textarea id="description" name="description" rows="3" required></textarea>

                        <label for="filePath">Αρχείο PDF (Προαιρετικό):</label>
                        <input type="file" name="pdf_file" accept=".pdf">

                        <button type="submit" id="submit" name="createTopic">Δημιουργία Θέματος</button>
                    </form>
                    <div id="popup-message" style="display:none;"></div>
                    <a href="ProfessorProfilePage.php" 
                    style="position: relative;
                           text-decoration: none;
                           background-color: #66b2b2;
                           color: #ffffff;
                           border-radius: 10px;
                           border: none;
                           font-size: medium;
                           cursor: pointer;
                           padding: 10px; "> Επιστροφή στο Προφίλ</a>
                </div>
            </div>
        </div>

        <script>
        document.getElementById('create-topic-form').addEventListener('submit', function (e) {
            e.preventDefault(); // Prevent the default form submission

            const formData = new FormData(this);

            fetch('createTopic.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                // Display the popup message
                const popup = document.getElementById('popup-message');
                popup.style.display = 'block';
                popup.textContent = data.message;
                popup.style.backgroundColor = data.status === 'success' ? 'green' : 'red';
                popup.style.color = 'white';
                popup.style.padding = '10px';
                popup.style.marginTop = '10px';

                // Hide the popup after 3 seconds
                setTimeout(() => {
                    popup.style.display = 'none';
                }, 3000);
            })
            .catch(error => {
                alert('An error occurred: ' + error.message);
            });
        });
        </script>
        
        <!-- Σύνδεση με το αρχείο JavaScript για τη λειτουργία των κουμπιών -->
        <script src="LogoutButton.js"></script>
        <script src="ProfViewCreateThesisPageButton.js"></script>
        <script src="ProfAssignThesisPageButton.js"></script>
        <script src="ProfViewListThesisPageButton.js"></script>
        <script src="ProfManageThesisPageButton.js"></script>
        <script src="ProfRequests3.js"></script>
        <script src="ProfStatistics.js"></script>
    </body>
</html>
