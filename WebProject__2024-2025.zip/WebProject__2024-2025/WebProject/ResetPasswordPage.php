<?php
require 'config.php'; // Include your database connection file

session_start();

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_POST['acEmail'];
    $newPassword = $_POST['newPassword'];
    $confirmPassword = $_POST['confirmPassword'];

    // Validate input
    if (empty($email) || empty($newPassword) || empty($confirmPassword)) {
        $error = "Παρακαλώ συμπληρώστε όλα τα πεδία.";
    } elseif ($newPassword !== $confirmPassword) {
        $error = "Οι κωδικοί δεν ταιριάζουν.";
    } else {
        // Check if the email exists in the database
        $sql = "SELECT * FROM users WHERE acEmail = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows == 0) {
            $error = "Λάθος E-mail / Το E-mail δεν υπάρχει.";
        } else {
            // Update the password (store as plain text)
            $updateSql = "UPDATE users SET password = ? WHERE acEmail = ?";
            $updateStmt = $conn->prepare($updateSql);
            $updateStmt->bind_param("ss", $newPassword, $email); // No hashing here

            if ($updateStmt->execute()) {
                $success = "Επιτυχής ενημέρωση κωδικού πρόσβασης";
            } else {
                $error = "Σφάλμα κατά την ενημέρωση κωδικού. Παρακαλώ δοκιμάστε ξανά.";
            }

            $updateStmt->close();
        }

        $stmt->close();
    }
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="el">
<head>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title id="titleLP">Κεντρική Υπηρεσία Ταυτοποίησης & Εξουσιοδότησης</title>
    <link rel="icon" type="image/png" href="ceid_logo.png">
    <link rel="stylesheet" href="ResetPasswordPage.css">
</head>
</head>
<body>

    <a href="https://www.ceid.upatras.gr" target="_self">
        <img src="upatras_ceid_logo.png" alt="Λογότυπο Τμήματος Πληροφορικής">
    </a>

    <div class="login-container">
    <h2>Ενημέρωση Κωδικού Χρήστη</h2>

    <!-- Display success or error messages -->
    <?php if (isset($error)): ?>
        <p style="color: red;"><?php echo $error; ?></p>
    <?php elseif (isset($success)): ?>
        <p style="color: green;"><?php echo $success; ?></p>
    <?php endif; ?>

    <!-- Password update form -->
    <form action="ResetPasswordPage.php" method="POST">
    
    <input type="email" id="acEmail" name="acEmail" placeholder="Διεύθυνση E-mail"required><br><br>

    <input type="password" id="newPassword" name="newPassword" placeholder="Nέος Κωδικός"required><br><br>

    <input type="password" id="confirmPassword" name="confirmPassword" placeholder="Επιβεβαίωση Κωδικού"required><br><br>

    <!-- Checkbox to show/hide passwords -->
    <label>
        <input type="checkbox" id="showPassword"> Εμφάνιση Κωδικού
    </label><br><br>

    <button type="submit" id="submit">Ενημέρωση Κωδικού</button>
    </form>
    </div>
</body>
<script>
    const showPassword = document.getElementById('showPassword');
    const newPasswordField = document.getElementById('newPassword');
    const confirmPasswordField = document.getElementById('confirmPassword');

    showPassword.addEventListener('change', () => {
        // Toggle the password visibility for both fields
        const type = showPassword.checked ? 'text' : 'password';
        newPasswordField.type = type;
        confirmPasswordField.type = type;
    });
</script>
</html>