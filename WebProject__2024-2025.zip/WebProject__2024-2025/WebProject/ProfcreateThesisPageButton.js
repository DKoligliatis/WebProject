document.getElementById("create-thesis").addEventListener("click", function() {
    window.location.href = 'ProfCreateThesisPage.php';
});