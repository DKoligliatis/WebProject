document.getElementById("edit-buttonPr").addEventListener("click", function() {
    window.location.href = 'updatePagePr.php';
});