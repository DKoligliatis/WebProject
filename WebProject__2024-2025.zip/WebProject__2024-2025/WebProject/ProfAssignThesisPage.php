<?php
require 'config.php'; // Σύνδεση με τη βάση δεδομένων
session_start();


// Χειρισμός AJAX αιτημάτων
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'];

    if ($action === 'searchStudent') {
        // Αναζήτηση Φοιτητή
        $searchTerm = $_POST['searchTerm'];
        $sql = "SELECT studentID, CONCAT(firstName, ' ', lastName) AS fullName, AM 
                FROM users 
                JOIN undergraduates ON users.userID = undergraduates.studentID 
                WHERE AM LIKE ? OR CONCAT(firstName, ' ', lastName) LIKE ?";
        $searchTerm = "%$searchTerm%";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ss", $searchTerm, $searchTerm);
        $stmt->execute();
        $result = $stmt->get_result();

        $students = [];
        while ($row = $result->fetch_assoc()) {
            $students[] = $row;
        }

        echo json_encode($students);
        exit();
    } elseif ($action === 'getAvailableTopics') {
        // Λήψη Διαθέσιμων Θεμάτων
        $profSupervID = $_SESSION['userID'];
        $sql = "SELECT topicID, title FROM topics WHERE profSupervID = ? AND status = 'Available'";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $profSupervID);
        $stmt->execute();
        $result = $stmt->get_result();

        $topics = [];
        while ($row = $result->fetch_assoc()) {
            $topics[] = $row;
        }

        echo json_encode($topics);
        exit();
    } elseif ($action === 'assignTopic') {
        // Ανάθεση Θέματος
        $topicID = $_POST['topicID'];
        $studentID = $_POST['studentID'];

        // Check if the student already has a diploma
        $checkSql = "SELECT diplomaID FROM diplomas WHERE studentID = ?";
        $checkStmt = $conn->prepare($checkSql);
        $checkStmt->bind_param("i", $studentID);
        $checkStmt->execute();
        $checkResult = $checkStmt->get_result();

        if ($checkResult->num_rows > 0) {
            // Student already has a diploma assigned
            echo json_encode(['success' => false, 'message' => 'Ο φοιτητής έχει ήδη ανατεθεί σε διπλωματική εργασία.']);
            exit();
        }

        // Proceed with topic assignment
        $sql = "CALL assignTopicToStudent(?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ii", $topicID, $studentID);

        try {
            $stmt->execute();
            echo json_encode(['success' => true, 'message' => 'Το θέμα ανατέθηκε προσωρινά στον φοιτητή.']);
        } catch (Exception $e) {
            echo json_encode(['success' => false, 'message' => $e->getMessage()]);
        }
        exit();
    }
    elseif ($action === 'getAssignedTopics') {
        // Λήψη Θεμάτων που έχουν ανατεθεί από τον καθηγητή
        $profSupervID = $_SESSION['userID'];
        $sql = "SELECT t.topicID, t.title, CONCAT(u.firstName, ' ', u.lastName) AS studentName,un.AM
                FROM topics t
                JOIN diplomas d ON t.topicID = d.topicID
                JOIN users u ON d.studentID = u.userID
                JOIN undergraduates un ON u.userID = un.studentID
                WHERE t.profSupervID = ? AND t.status = 'Assigned'";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $profSupervID);
        $stmt->execute();
        $result = $stmt->get_result();


    
        $assignments = [];
        while ($row = $result->fetch_assoc()) {
            $assignments[] = $row;
        }
    
        echo json_encode($assignments);
        exit();

    }elseif ($action === 'makeAvailable') {
        $topicID = $_POST['topicID'];
        $AM = $_POST['AM'];
    
        if (empty($AM)) {
            echo json_encode(['success' => false, 'message' => 'No AM provided.']);
            exit();
        }
    
        $conn->begin_transaction(); // Start transaction
    
        try {
           
            $sqlDeleteCommittees = "
                DELETE FROM committees 
                WHERE committeeID IN (
                    SELECT committeeID 
                    FROM diplomas 
                    WHERE studentID IN (SELECT studentID FROM undergraduates WHERE AM = ?)
                )
            ";
            $stmtDeleteCommittees = $conn->prepare($sqlDeleteCommittees);
            if (!$stmtDeleteCommittees) {
                throw new Exception('Error preparing statement for deleting from committees: ' . $conn->error);
            }
            $stmtDeleteCommittees->bind_param('i', $AM);
            $stmtDeleteCommittees->execute();
    
            $sqlDeleteDiplStatusLog = "
            DELETE FROM diplstatuslog 
            WHERE diplID = (SELECT diplomaID 
                            FROM diplomas 
                            WHERE studentID IN (SELECT studentID 
                                                FROM undergraduates 
                                                WHERE AM = ?)
                            )LIMIT 25";

            $sqlDeleteDiplStatusLog = $conn->prepare($sqlDeleteDiplStatusLog);
            if (!$sqlDeleteDiplStatusLog) {
                throw new Exception('Error preparing statement for deleting from diplstatuslog: ' . $conn->error);
            }
            $sqlDeleteDiplStatusLog->bind_param('i', $AM);
            $sqlDeleteDiplStatusLog->execute();

            $sqlDeleteProfDiplStatusLog = "DELETE FROM professordiplomalog 
                                          WHERE diplomaID = (SELECT diplomaID FROM diplomas WHERE studentID 
                                                            IN (SELECT studentID FROM undergraduates WHERE AM = ?) )LIMIT 25;";

            $sqlDeleteProfDiplStatusLog = $conn->prepare($sqlDeleteProfDiplStatusLog);
            if (!$sqlDeleteProfDiplStatusLog) {
                throw new Exception('Error preparing statement for deleting from diplstatuslog: ' . $conn->error);
            }
            $sqlDeleteProfDiplStatusLog->bind_param('i', $AM);
            $sqlDeleteProfDiplStatusLog->execute();
            
            $sqlDeleteDiplomas = "
                DELETE FROM diplomas 
                WHERE studentID IN (SELECT studentID FROM undergraduates WHERE AM = ?) LIMIT 25";

            $stmtDeleteDiplomas = $conn->prepare($sqlDeleteDiplomas);
            if (!$stmtDeleteDiplomas) {
                throw new Exception('Error preparing statement for deleting from diplomas: ' . $conn->error);
            }
            $stmtDeleteDiplomas->bind_param('i', $AM);
            $stmtDeleteDiplomas->execute();
    
            
            $sqlUpdateTopic = "
                UPDATE topics 
                SET status = 'Available' 
                WHERE topicID = ?
            ";
            $stmtUpdateTopic = $conn->prepare($sqlUpdateTopic);
            if (!$stmtUpdateTopic) {
                throw new Exception('Error preparing statement for updating topic status: ' . $conn->error);
            }
            $stmtUpdateTopic->bind_param('i', $topicID);
            $stmtUpdateTopic->execute();
    
            $conn->commit(); // Commit transaction
    
            echo json_encode(['success' => true, 'message' => 'Η ανάθεση ακυρώθηκε και το θέμα είναι διαθέσιμο.']);
        } catch (Exception $e) {
            $conn->rollback(); // Rollback transaction on error
            error_log('Error in makeAvailable: ' . $e->getMessage()); // Log error to server logs
            echo json_encode(['success' => false, 'message' => 'Σφάλμα κατά την ακύρωση: ' . $e->getMessage()]);
        }
        exit();
    }
    
}
?>

<!DOCTYPE html>
<html lang="el">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ανάθεση Θέματος</title>
    <link rel="stylesheet" href="ProfAssignThesisPage.css">
</head>
<body>
    <div class="container">
        <!-- Άνω τμήμα της σελίδας με το λογότυπο και το κουμπί εξόδου -->
        <div class="upper-section">
			<!-- Σύνδεσμος για να επιστρέψει ο χρήστης στην ιστοσελίδα του τμήματος -->
			<a href="https://www.ceid.upatras.gr" target="_self">
				<!-- Εικόνα του λογότυπου του τμήματος -->
				<img src="upatras_ceid_logo.png" alt="upatras_ceid_logo">
			</a>

			<!-- Κουμπί εξόδου για αποσύνδεση από την πλατφόρμα -->
			<button class="logout-button"onclick="window.location.href='logout.php'">Έξοδος</button>
		</div>

        <!-- Κουμπί για την αλλαγή γλώσσας της σελίδας -->
        <div class="language-toggle">
            <button id="languageButton">
                <!-- Εικονίδιο που δείχνει την επιλογή γλώσσας -->
                <img src="language.png" alt="languageIcon">
            </button>
        </div>
		
        <!-- Κύριο περιεχόμενο της σελίδας -->
        <div class="container">  
            <div class="main-menu">   
                <!-- Κουμπί για το προφίλ του καθηγητή -->
                <button class="menu-item" id="profile">Προφίλ </button>
                
                <!-- Κουμπί για την προβολή και δημιουργία θεμάτων προς ανάθεση -->
                <button class="menu-item" id="view-and-create-thesis">Προβολή και Δημιουργία <br>Θεμάτων προς Ανάθεση</button>  
                
                <!-- Κουμπί για την αρχική ανάθεση θέματος σε φοιτητή -->
                <button class="menu-item" id="assign-thesis">Αρχική Ανάθεση Θέματος <br>σε Φοιτητή </button>  
                
                <!-- Κουμπί για την προβολή λίστας διπλωματικών εργασιών -->
                <button class="menu-item" id="view-list-thesis">Προβολή Λίστας <br>Διπλωματικών</button>

                <button class="menu-item" id="view-requests-3">Προβολή Προσκλήσεων <br> Συμμετοχής σε Τριμελή</button>

                <!-- Κουμπί για την προβολή στατιστικών -->
                <button class="menu-item" id="view-sattistics">Προβολή Στατιστικών</button>
                
                <!-- Κουμπί για τη διαχείριση των διπλωματικών εργασιών -->
                <button class="menu-item" id="manage-thesis">Διαχείριση Διπλωματικών <br>Εργασιών</button>
            </div>  
            

        <div class="content ">
        
        <!-- Αναζήτηση Φοιτητή -->
        <div>
            <label for="search-student">Αναζήτηση Φοιτητή (με ΑΜ ή Ονοματεπώνυμο):</label>
            <input type="text" id="search-student" placeholder="Πληκτρολογήστε ΑΜ ή Όνομα">
            <button id="search-button">Αναζήτηση</button>
        </div>

        <!-- Αποτελέσματα Αναζήτησης -->
        <div id="search-results">
            <h2>Αποτελέσματα Αναζήτησης</h2>
            <table>
                <thead>
                    <tr>
                        <th>ΑΜ</th>
                        <th>Ονοματεπώνυμο</th>
                        <th>Ενέργεια</th>
                    </tr>
                </thead>
                <tbody>
                    <!-- Δεδομένα θα φορτωθούν δυναμικά -->
                </tbody>
            </table>
        </div>

        <!-- Επιλογή Θέματος -->
        <div id="topics-section">
            <h2>Διαθέσιμα Θέματα</h2>
            <select id="topic-select" style="padding: 10px; border: 1px solid #ccc; border-radius: 5px;">
                <option value="">Επιλέξτε Θέμα</option>
            </select>
            <button id="assign-button" disabled>Ανάθεση</button>
        </div>


        <!-- Λίστα Θεμάτων που έχουν ανατεθεί -->
    <div id="assigned-topics">
        <h2>Θέματα Ανατεθειμένα σε Φοιτητές</h2>
        <table>
            <thead>
                <tr>
                <th>ID Θέματος</th>
                <th>Τίτλος</th>
                <th>Ονοματεπώνυμο Φοιτητή</th>
                <th>ΑΜ Φοιτητή</th>
                <th>Ενέργεια</th>
                </tr>
            </thead>
            <tbody>
                <!-- Τα δεδομένα θα φορτωθούν δυναμικά -->
            </tbody>
        </table>
        </div>
    </div>
      

<script>
    let selectedStudentID = null;

    // Αναζήτηση Φοιτητή
        document.getElementById('search-button').addEventListener('click', () => {
            const searchTerm = document.getElementById('search-student').value;

            fetch('', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: `action=searchStudent&searchTerm=${encodeURIComponent(searchTerm)}`
            })
                .then(response => response.json())
                .then(data => {
                    const resultsTable = document.querySelector('#search-results tbody');
                    resultsTable.innerHTML = '';

                    data.forEach(student => {
                        const row = document.createElement('tr');
                        row.innerHTML = `
                            <td>${student.AM}</td>
                            <td>${student.fullName}</td>
                            <td><button onclick="selectStudent(${student.studentID})"style="background-color: #4CAF50;
                                                                                            color: white;
                                                                                            padding: 10px 20px;
                                                                                            border: none;
                                                                                            border-radius: 8px;
                                                                                            cursor: pointer;">Επιλογή</button></td>`;
                        resultsTable.appendChild(row);
                    });
                });
        });

        // Επιλογή Φοιτητή
        function selectStudent(studentID) {
            selectedStudentID = studentID;
            document.getElementById('assign-button').disabled = false;

            // Φόρτωση διαθέσιμων θεμάτων
            fetch('', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: 'action=getAvailableTopics'
            })
                .then(response => response.json())
                .then(data => {
                    const topicSelect = document.getElementById('topic-select');
                    topicSelect.innerHTML = '<option value="">Επιλέξτε Θέμα</option>';

                    data.forEach(topic => {
                        const option = document.createElement('option');
                        option.value = topic.topicID;
                        option.textContent = topic.title;
                        topicSelect.appendChild(option);
                    });
                });
        }

        // Ανάθεση Θέματος
        document.getElementById('assign-button').addEventListener('click', () => {
            const topicID = document.getElementById('topic-select').value;

            if (!selectedStudentID || !topicID) {
                alert('Παρακαλώ επιλέξτε φοιτητή και θέμα.');
                return;
            }

            fetch('', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: `action=assignTopic&topicID=${topicID}&studentID=${selectedStudentID}`
            })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        alert(data.message);
                        loadAssignedTopics();
                    } else {
                        alert('Σφάλμα: ' + data.message);
                    }
                });
        });

       
      // Φόρτωση Αναθέσεων
function loadAssignedTopics() {
    fetch('', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: 'action=getAssignedTopics'
    })
        .then(response => response.json())
        .then(data => {
            const assignedTable = document.querySelector('#assigned-topics tbody');
            assignedTable.innerHTML = ''; // Καθαρισμός πίνακα

            if (data.length === 0) {
                assignedTable.innerHTML = '<tr><td colspan="5">Δεν υπάρχουν αναθέσεις.</td></tr>';
                return;
            }

            data.forEach(assignment => {
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td>${assignment.topicID}</td>
                    <td>${assignment.title}</td>
                    <td>${assignment.studentName}</td>
                    <td>${assignment.AM}</td>
                    <td>
                        <button 
                            onclick="makeAvailable(${assignment.topicID}, '${assignment.AM}')"
                            style="background-color: #f44336; color: white; padding: 10px 20px; border: none; border-radius: 8px; cursor: pointer;">
                            Ακύρωση Ανάθεσης
                        </button>
                    </td>
                `;
                assignedTable.appendChild(row);
            });
        })
        .catch(error => {
            console.error('Σφάλμα στη φόρτωση των αναθέσεων:', error);
            alert('Παρουσιάστηκε σφάλμα. Προσπαθήστε ξανά.');
        });
}

// Ενημέρωση Κατάστασης σε Available
function makeAvailable(topicID, AM) {
    if (confirm('Είστε σίγουροι ότι θέλετε να ακυρώσετε την ανάθεση;')) {
        fetch('', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: `action=makeAvailable&topicID=${topicID}&AM=${encodeURIComponent(AM)}`
        })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert(data.message);
                    loadAssignedTopics(); // Reload assignments
                } else {
                    alert('Σφάλμα: ' + data.message);
                }
            })
            .catch(error => {
                console.error('Σφάλμα κατά την ενημέρωση:', error);
                alert('Παρουσιάστηκε σφάλμα. Προσπαθήστε ξανά.');
            });
    }
}

// Αυτόματη Φόρτωση Αναθέσεων κατά την Εκκίνηση
window.onload = () => {
    loadAssignedTopics();
};
</script>

</body>
<script src="ProfViewCreateThesisPageButton.js"></script>
<script src="ProfessorProfileButton.js"></script>
<script src="ProfViewListThesisPageButton.js"></script>
<script src="ProfManageThesisPageButton.js"></script>
<script src="ProfRequests3.js"></script>
<script src="ProfStatistics.js"></script>


</html>
