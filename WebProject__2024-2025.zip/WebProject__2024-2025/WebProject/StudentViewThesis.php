<?php
require 'config.php'; // Σύνδεση με τη βάση δεδομένων
session_start();

$userID = $_SESSION['userID']; // Ανακτούμε το ID του χρήστη από τη συνεδρία

// Ερώτημα για ανάκτηση στοιχείων της διπλωματικής εργασίας
$sql = "
   SELECT 
    t.title AS topic_title,
    t.description AS topic_description,
    t.filePath AS topic_file,
    d.status AS topic_status,
    d.grade AS grade,
    CONCAT(
        CONCAT(u1.firstName, ' ', u1.lastName), ' (Supervisor)', ', ',
        IFNULL(CONCAT(u2.firstName, ' ', u2.lastName), 'N/A'), ' (Member 1)', ', ',
        IFNULL(CONCAT(u3.firstName, ' ', u3.lastName), 'N/A'), ' (Member 2)'
    ) AS committee_members,
    DATEDIFF(CURDATE(), d.startDate) AS days_since_assignment,
    t.filePath
FROM topics t
LEFT JOIN diplomas d ON t.topicID = d.topicID
LEFT JOIN committees c ON d.committeeID = c.committeeID
LEFT JOIN professors p1 ON c.supervisorID = p1.profID
LEFT JOIN professors p2 ON c.member1ID = p2.profID
LEFT JOIN professors p3 ON c.member2ID = p3.profID
LEFT JOIN users u1 ON p1.profID = u1.userID
LEFT JOIN users u2 ON p2.profID = u2.userID
LEFT JOIN users u3 ON p3.profID = u3.userID
WHERE d.studentID = ?;
";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $userID);
$stmt->execute();
$result = $stmt->get_result();

// Αποθήκευση των δεδομένων για χρήση στην HTML
$thesisData = $result->fetch_assoc();

$stmt->close();
$conn->close();
?>

<!DOCTYPE html>
<html>
<head>
    <title>ΤΜΥΠ | Προβολή Διπλωματικής Εργασίας</title>
    <link rel="icon" type="image/png" href="ceid_logo.png">
    <link rel="stylesheet" href="StudentProfilePage.css">

    <style>
        .congratulations-message {
            display: none;
            text-align: center;
            font-size: 24px;
            color: green;
            padding: 20px;
            border: 2px solid green;
            background-color: #f0f8ff;
            border-radius: 10px;
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <div class="upper-section">
        <a href="https://www.ceid.upatras.gr" target="_self">
            <img src="upatras_ceid_logo.png" alt="upatras_ceid_logo">
        </a>
        <button class="logout-button" id="logout-button" onclick="window.location.href='logout.php'">Έξοδος</button>
    </div>

    <div class="container">
        <div class="main-menu">
            <button class="menu-item" id="profile" onclick="window.location.href='StudentProfilePage.php'">Προφίλ</button>
            <button class="menu-item" id="view-thesis" onclick="window.location.href='StudentViewThesisPage.php'">Προβολή Θέματος<br>Διπλωματικής Εργασίας</button>
            <button class="menu-item" id="manage-thesis" onclick="window.location.href='StudentManageThesisPage.php'">Διαχείριση Διπλωματικής<br>Εργασίας</button>
        </div>

        <div class="content">
            <div class="profile-container">
                <div class="thesis-header">
                    <div class="thesis-info">
                        <h1>Διπλωματική Εργασία</h1>
                    </div>
                </div>

                <div class="thesis-details">
                    <h2>Λεπτομέρειες Θέματος</h2>
                    <p><strong>Θέμα:</strong> <?php echo htmlspecialchars($thesisData['topic_title'] ?? 'Δεν έχει οριστεί'); ?></p>
                    <p><strong>Περιγραφή:</strong> <?php echo htmlspecialchars($thesisData['topic_description'] ?? 'Δεν έχει οριστεί'); ?></p>
                    <p><strong>Αρχείο Περιγραφής: <a href="download.php?filename=<?php echo htmlspecialchars($thesisData['topic_file'] ?? ''); ?>" download>Download PDF</a></strong> </p>
                    <p><strong>Κατάσταση:</strong> <?php echo htmlspecialchars($thesisData['topic_status'] ?? 'Δεν έχει οριστεί'); ?></p>
                    <p><strong>Μέλη Τριμελούς Εξέτασης:</strong> <?php echo htmlspecialchars($thesisData['committee_members'] ?? 'Δεν έχουν οριστεί'); ?></p>
                    <p><strong>Βαθμός Διπλωματικής:</strong> <?php echo htmlspecialchars($thesisData['grade'] ?? 'Δεν έχει οριστεί'); ?></p>
                    <p><strong>Διάστημα Ανάθεσης:</strong> 
                        <?php 
                        echo isset($thesisData['days_since_assignment']) 
                            ? $thesisData['days_since_assignment'] . ' ημέρες από την ανάθεση'
                            : 'Δεν έχει ανατεθεί';
                        ?>
                    </p>

                    <!-- Congratulations Message -->
                    <div id="congratulations" class="congratulations-message">
                        Συγχαρητήρια για την επιτυχία σας!
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Confetti -->
    <script>
        'use strict';

        window.onload = function() {
            // Globals
            var random = Math.random
                , cos = Math.cos
                , sin = Math.sin
                , PI = Math.PI
                , PI2 = PI * 2
                , timer = undefined
                , frame = undefined
                , confetti = [];

            var particles = 10
                , spread = 40
                , sizeMin = 3
                , sizeMax = 12 - sizeMin
                , eccentricity = 10
                , deviation = 100
                , dxThetaMin = -.1
                , dxThetaMax = -dxThetaMin - dxThetaMin
                , dyMin = .13
                , dyMax = .18
                , dThetaMin = .4
                , dThetaMax = .7 - dThetaMin;

            var colorThemes = [
                function() {
                    return color(200 * random()|0, 200 * random()|0, 200 * random()|0);
                }, function() {
                    var black = 200 * random()|0; return color(200, black, black);
                }, function() {
                    var black = 200 * random()|0; return color(black, 200, black);
                }, function() {
                    var black = 200 * random()|0; return color(black, black, 200);
                }, function() {
                    return color(200, 100, 200 * random()|0);
                }, function() {
                    return color(200 * random()|0, 200, 200);
                }, function() {
                    var black = 256 * random()|0; return color(black, black, black);
                }, function() {
                    return colorThemes[random() < .5 ? 1 : 2]();
                }, function() {
                    return colorThemes[random() < .5 ? 3 : 5]();
                }, function() {
                    return colorThemes[random() < .5 ? 2 : 4]();
                }
            ];

            function color(r, g, b) {
                return 'rgb(' + r + ',' + g + ',' + b + ')';
            }

            // Cosine interpolation
            function interpolation(a, b, t) {
                return (1-cos(PI*t))/2 * (b-a) + a;
            }

            // Create a 1D Maximal Poisson Disc over [0, 1]
            var radius = 1/eccentricity, radius2 = radius+radius;
            function createPoisson() {
                // domain is the set of points which are still available to pick from
                // D = union{ [d_i, d_i+1] | i is even }
                var domain = [radius, 1-radius], measure = 1-radius2, spline = [0, 1];
                while (measure) {
                    var dart = measure * random(), i, l, interval, a, b, c, d;

                    // Find where dart lies
                    for (i = 0, l = domain.length, measure = 0; i < l; i += 2) {
                        a = domain[i], b = domain[i+1], interval = b-a;
                        if (dart < measure+interval) {
                            spline.push(dart += a-measure);
                            break;
                        }
                        measure += interval;
                    }
                    c = dart-radius, d = dart+radius;

                    // Update the domain
                    for (i = domain.length-1; i > 0; i -= 2) {
                        l = i-1, a = domain[l], b = domain[i];
                        // c---d          c---d  Do nothing
                        //   c-----d  c-----d    Move interior
                        //   c--------------d    Delete interval
                        //         c--d          Split interval
                        //       a------b
                        if (a >= c && a < d)
                            if (b > d) domain[l] = d; // Move interior (Left case)
                            else domain.splice(l, 2); // Delete interval
                        else if (a < c && b > c)
                            if (b <= d) domain[i] = c; // Move interior (Right case)
                            else domain.splice(i, 0, c, d); // Split interval
                    }

                    // Re-measure the domain
                    for (i = 0, l = domain.length, measure = 0; i < l; i += 2)
                        measure += domain[i+1]-domain[i];
                }

                return spline.sort();
            }

            // Create the overarching container
            var container = document.createElement('div');
            container.style.position = 'fixed';
            container.style.top      = '0';
            container.style.left     = '0';
            container.style.width    = '100%';
            container.style.height   = '0';
            container.style.overflow = 'visible';
            container.style.zIndex   = '9999';

            // Confetto constructor
            function Confetto(theme) {
                this.frame = 0;
                this.outer = document.createElement('div');
                this.inner = document.createElement('div');

                this.outer.appendChild(this.inner);

                var outerStyle = this.outer.style, innerStyle = this.inner.style;
                outerStyle.position = 'absolute';
                outerStyle.width  = (sizeMin + sizeMax * random()) + 'px';
                outerStyle.height = (sizeMin + sizeMax * random()) + 'px';
                innerStyle.width  = '100%';
                innerStyle.height = '100%';
                innerStyle.backgroundColor = theme();

                outerStyle.perspective = '50px';
                outerStyle.transform = 'rotate(' + (360 * random()) + 'deg)';
                this.axis = 'rotate3D(' +
                    cos(360 * random()) + ',' +
                    cos(360 * random()) + ',0,'; 
                this.theta = 360 * random();
                this.dTheta = dThetaMin + dThetaMax * random();
                innerStyle.transform = this.axis + this.theta + 'deg)';

                this.x = window.innerWidth * random();
                this.y = -deviation;
                this.dx = sin(dxThetaMin + dxThetaMax * random());
                this.dy = dyMin + dyMax * random();
                outerStyle.left = this.x + 'px';
                outerStyle.top  = this.y + 'px';

                // Create the periodic spline
                this.splineX = createPoisson();
                this.splineY = [];
                for (var i = 1, l = this.splineX.length-1; i < l; ++i)
                    this.splineY[i] = deviation * random();
                this.splineY[0] = this.splineY[l] = deviation * random();

                this.update = function(height, delta) {
                    this.frame += delta;
                    this.x += this.dx * delta;
                    this.y += this.dy * delta;
                    this.theta += this.dTheta * delta;

                    // Compute spline and convert to polar
                    var phi = this.frame % 7777 / 7777, i = 0, j = 1;
                    while (phi >= this.splineX[j]) i = j++;
                    var rho = interpolation(
                        this.splineY[i],
                        this.splineY[j],
                        (phi-this.splineX[i]) / (this.splineX[j]-this.splineX[i])
                    );
                    phi *= PI2;

                    outerStyle.left = this.x + rho * cos(phi) + 'px';
                    outerStyle.top  = this.y + rho * sin(phi) + 'px';
                    innerStyle.transform = this.axis + this.theta + 'deg)';
                    return this.y > height+deviation;
                };
            }

            function poof() {
                if (!frame) {
                    // Append the container
                    document.body.appendChild(container);

                    // Add confetti
                    var theme = colorThemes[0]
                        , count = 0;
                    (function addConfetto() {
                        var confetto = new Confetto(theme);
                        confetti.push(confetto);
                        container.appendChild(confetto.outer);
                        timer = setTimeout(addConfetto, spread * random());
                    })(0);

                    // Start the loop
                    var prev = undefined;
                    requestAnimationFrame(function loop(timestamp) {
                        var delta = prev ? timestamp - prev : 0;
                        prev = timestamp;
                        var height = window.innerHeight;

                        for (var i = confetti.length-1; i >= 0; --i) {
                            if (confetti[i].update(height, delta)) {
                                container.removeChild(confetti[i].outer);
                                confetti.splice(i, 1);
                            }
                        }

                        if (confetti.length) frame = requestAnimationFrame(loop);
                        else frame = undefined;
                    });
                }
            }

            // Trigger confetti on successful grade
            const grade = <?php echo $thesisData['grade'] ?? 0; ?>;
            if (grade >= 5) {
                poof();
                document.getElementById("congratulations").style.display = "block";
            }
        };
    </script>
    <script src="StudentViewThesisButton.js"></script>
    <script src="StudentProfileButton.js"></script>
    <script src="StudentManageThesisButton.js"></script>
</body>
</html>
