<?php
session_start();

// Ανάκτηση δεδομένων χρήστη από τη συνεδρία
$userID = htmlspecialchars($_SESSION['userID']);
$firstName = htmlspecialchars($_SESSION['firstName']);
$lastName = htmlspecialchars($_SESSION['lastName']);
$email = htmlspecialchars($_SESSION['acEmail']);
$address = htmlspecialchars($_SESSION['address']);
$phoneMobile = htmlspecialchars($_SESSION['phone_mobile']);
$phoneHome = htmlspecialchars($_SESSION['phone_home']);
?>


<!DOCTYPE html>
<html>
    <head>
        <!-- Τίτλος της σελίδας που εμφανίζεται στην καρτέλα -->
        <title>ΤΜΥΠ | Το προφίλ μου</title>
        
        <!-- Ορισμός της εικόνας που εμφανίζεται στην καρτέλα -->
        <link rel="icon" type="image/png" href="ceid_logo.png">
        
        <!-- Σύνδεση με το αρχείο CSS για την εμφάνιση της σελίδας -->
        <link rel="stylesheet" href="SecretaryProfilePage.css">
        
    </head>

    <body>
        <!-- Άνω τμήμα της σελίδας με το λογότυπο και το κουμπί εξόδου -->
        <div class="upper-section">
			<!-- Σύνδεσμος για να επιστρέψει ο χρήστης στην ιστοσελίδα του τμήματος -->
			<a href="https://www.ceid.upatras.gr" target="_self">
				<!-- Εικόνα του λογότυπου του τμήματος -->
				<img src="upatras_ceid_logo.png" alt="upatras_ceid_logo">
			</a>

			<!-- Κουμπί εξόδου για αποσύνδεση από την πλατφόρμα -->
			<button class="logout-button">Έξοδος</button>
		</div>

        <!-- Κουμπί για την αλλαγή γλώσσας της σελίδας -->
        <div class="language-toggle">
            <button id="languageButton">
                <!-- Εικονίδιο που δείχνει την επιλογή γλώσσας -->
                <img src="language.png" alt="languageIcon">
            </button>
        </div>
		
        <!-- Κύριο περιεχόμενο της σελίδας -->
        <div class="container">  
            <div class="main-menu">   
                <!-- Κουμπί για το προφίλ της γραμματείας -->
                <button class="menu-item" id="profile">Προφίλ </button>
                
                <!-- Κουμπί για την προβολή των διπλωματικών εργασιών -->
                <button class="menu-item" id="view-thesis">Προβολή Διπλωματικών <br>Εργασιών</button>  
                
                <!-- Κουμπί για την εισαγωγή δεδομένων για τις διπλωματικές εργασίες -->
                <button class="menu-item" id="data-input">Εισαγωγή Δεδομένων </button>  

            </div>  
            
            <div class="content">
                <!-- Προφίλ γραμματείας -->
                <div class="profile-container">
                    <div class="profile-header">
                        <!-- Εικόνα προφίλ της γραμματείας -->
                        <img class="profile-picture" src="face.jpg" alt="Profile Picture">
                        
                        <div class="profile-info">
                            <!-- Όνομα και στοιχεία της γραμματείας -->
                            <h1><?php echo $firstName . " " . $lastName?></h1>
                            <p><?php echo $userID?></p>
                        </div>
                        
                        <!-- Κουμπί για την επεξεργασία του προφίλ -->
                        <button class="edit-button"id="edit-buttonSec">Αλλαγή</button>
                    </div>
                    
                    <!-- Προσωπικά στοιχεία της γραμματείας -->
                    <div class="profile-details">
                        <h2>Προσωπικά Στοιχεία</h2>
                        <p><strong>E-mail:</strong> <?php echo $email?> </p>
                        <p><strong>Αριθμός μητρώου:</strong> <?php echo $userID?></p>
                        <p><strong>Κατηγορία:</strong> Γραμματεία</p>
                        <p><strong>Κινητό Τηλέφωνο:</strong><?php echo $phoneMobile?></p>
                        <p><strong>Σταθερό Τηλέφωνο:</strong><?php echo $phoneHome?></p>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Σύνδεση με το αρχείο JavaScript για τη λειτουργία του κουμπιού εξόδου -->
        <script src="LogoutButton.js"></script>
        <script src="editButtonSec.js"></script>
        <script src="SecretaryProfileButton.js"></script>
        <script src="SecretaryViewThesisPageButton.js"></script>
        <script src="SecretaryInsertDataPageButton.js"></script>
    </body>
</html>