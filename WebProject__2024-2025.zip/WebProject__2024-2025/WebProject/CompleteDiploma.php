<?php
require 'config.php';
session_start();

// Παίρνουμε το topicID από τη φόρμα
$topicID = $_POST['topicID'];

// Ενημερώνουμε την κατάσταση του diploma σε "Under Review"
$sql = "UPDATE diplomas SET status = 'Completed' WHERE topicID = ?";

$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "i", $topicID);

// Εκτελούμε το query
if (mysqli_stmt_execute($stmt)) {
    echo "Η κατάσταση άλλαξε επιτυχώς!";
} else {
    echo "Σφάλμα κατά την αλλαγή κατάστασης.";
}

mysqli_stmt_close($stmt);
mysqli_close($conn);
?>