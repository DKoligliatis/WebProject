document.getElementById("manage-thesis").addEventListener("click", function() {
    window.location.href = 'ProfManageThesisPage.php';
});