<?php
require 'config.php'; // Database connection
session_start(); // Start session

// Check if the professor is logged in
if (!isset($_SESSION['userID'])) {
    die("Unauthorized access. Please log in."); // Redirect or show an error
}

$profSupervID = $_SESSION['userID']; // Get the logged-in professor's ID
$popupMessages = "";

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Handle topic updates
    if (isset($_POST['update'])) {
        foreach ($_POST['topicID'] as $index => $topicID) {
            $title = $conn->real_escape_string($_POST['title'][$index]);
            $description = $conn->real_escape_string($_POST['description'][$index]);

            // Handle file upload
            $filePath = null;
            if (isset($_FILES['filePath']['tmp_name'][$index]) && $_FILES['filePath']['tmp_name'][$index] != "") {
                $filePath = file_get_contents($_FILES['filePath']['tmp_name'][$index]);
            }

            // Update the topic in the database
            $stmt = $conn->prepare("UPDATE topics SET title=?, description=?, filePath=? WHERE topicID=? AND profSupervID=?");
            $stmt->bind_param("ssssi", $title, $description, $filePath, $topicID, $profSupervID);

            if (!$stmt->execute()) {
                echo json_encode(["status" => "error", "message" => "Error updating topic ID $topicID: " . $stmt->error]);
                exit;
            }
        }
        echo json_encode(["status" => "success", "message" => "Επιτυχής ανανέωση των Διπλωματικών."]);
        exit;
    }

    // Handle topic deletion
    if (isset($_POST['delete'])) {
        $topicIDToDelete = $_POST['topicIDToDelete'];
        $sql = "DELETE FROM topics WHERE topicID='$topicIDToDelete' AND profSupervID='$profSupervID'";

        if ($conn->query($sql) === TRUE) {
            echo json_encode(["status" => "success", "message" => "Η Διπλωματική διαγραφθηκε επιτυχώς."]);
        } else {
            echo json_encode(["status" => "error", "message" => "Σφάλμα κατά την διαγραφή Διπλωματικής: " . $conn->error]);
        }
        exit; // End script to handle only this request
    }
}

// Fetch all records for the logged-in professor
$sql = "SELECT topicID, title, description, status, filePath 
        FROM topics 
        WHERE profSupervID='$profSupervID'";

$result = $conn->query($sql);

// Check for query errors
if (!$result) {
    die("Error fetching records: " . $conn->error);
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>ΤΜΥΠ | Προβολή Διπλωματικών Εργασιών</title>
    <link rel="icon" type="image/png" href="ceid_logo.png">
    <link rel="stylesheet" href="ProfViewThesisPage.css">
</head>
<body>
    <div class="upper-section">
        <a href="https://www.ceid.upatras.gr" target="_self">
            <img src="upatras_ceid_logo.png" alt="upatras_ceid_logo">
        </a>
        <button class="logout-button" onclick="window.location.href='logout.php'">Έξοδος</button>
    </div>

    <div class="container">  
        <div class="main-menu">   
            <button class="menu-item" id="profile">Προφίλ</button>
            <button class="menu-item" id="view-and-create-thesis">Προβολή και Δημιουργία <br>Θεμάτων προς Ανάθεση</button>  
            <button class="menu-item" id="assign-thesis">Αρχική Ανάθεση Θέματος <br>σε Φοιτητή</button>  
            <button class="menu-item" id="view-list-thesis">Προβολή Λίστας <br>Διπλωματικών</button>
            <button class="menu-item" id="view-requests-3">Προβολή Προσκλήσεων <br> Συμμετοχής σε Τριμελή</button>
            <button class="menu-item" id="view-sattistics">Προβολή Στατιστικών</button>
            <button class="menu-item" id="manage-thesis">Διαχείριση Διπλωματικών <br>Εργασιών</button>
        </div>  

        <div class="content">
            <h1>Προβολή Διπλωματικών Εργασιών</h1>
            <?php
            if ($result->num_rows > 0) {
                echo "<form action='' method='post' enctype='multipart/form-data'>"; // Form for update
                echo "<ul>";
                while ($row = $result->fetch_assoc()) {
                    echo "<li>";
                    echo "<input type='hidden' name='topicID[]' value='" . $row['topicID'] . "'>";
                    echo "Topic ID: <input type='text' value='" . $row['topicID'] . "' disabled style='background-color: #f0f0f0; border: 1px solid #ccc; border-radius: 4px; padding: 5px; margin: 5px 0;'> - ";
                    echo "Title: <textarea name='title[]' rows='2' style='background-color: #fff; border: 1px solid #ccc; border-radius: 4px; padding: 5px; margin: 5px 0; width: 100%;'>" . htmlspecialchars($row['title']) . "</textarea>";
                    echo "Description: <textarea name='description[]' rows='4' style='background-color: #fff; border: 1px solid #ccc; border-radius: 4px; padding: 5px; margin: 5px 0; width: 100%;'>" . htmlspecialchars($row['description']) . "</textarea>";
                    echo "Status: <textarea name='status[]' rows='2' disabled style='background-color: #fff; border: 1px solid #ccc; border-radius: 4px; padding: 5px; margin: 5px 0; width: 100%;'>" . htmlspecialchars($row['status']) . "</textarea>";

                    if ($row['filePath']) {
                        echo "<p>Υπάρχει ανεβάσμένο αρχείο για αυτήν την διπλωματική. Μπορείτε να ανεβάσετε νέο:</p>";
                    } else {
                        echo "<p>Δεν υπάρχει αρχείο για αυτήν την διπλωματική.</p>";
                    }
                    echo "Αρχείο: <input type='file' name='filePath[]'>";
                    echo "<br><br>";
                    // Delete button
                    echo "<form action='' method='post' style='display:inline;' onsubmit='return confirmDelete()'>";
                    echo "<input type='hidden' name='topicIDToDelete' value='" . $row['topicID'] . "'>";
                    echo "<button type='submit' name='delete' value='Delete' style='background-color: #f44343; color: white; padding: 10px 20px; margin-right: 10px; border: none; border-radius: 8px; cursor: pointer; font-size: medium;'>Διαγραφή Διπλωματικής</button>";
                    echo "</form>";

                    // Update button
                    echo "<input type='submit' name='update' value='Ανανέωση Διπλωματικής' onclick='return confirmUpdate()' style='background-color: #4CAF50; color: white; padding: 10px 20px; border: none; border-radius: 8px; cursor: pointer; font-size: medium;'>";
                    echo "<br><br>";
                    echo "</li>";
                }
                echo "</ul>";
                echo "<br>";
                echo "</form>";
            } else {
                echo "No records found.";
            }
            ?>
        </div>
    </div>

    <script>
        function confirmDelete() {
    return confirm("Είστε σίγουροι ότι θέλετε να διαγράψετε αυτή τη Διπλωματική;");
}

// Update confirmation
function confirmUpdate() {
    return confirm("Είστε σίγουροι ότι θέλετε να ανανεώσετε αυτή τη Διπλωματική;");
}
    </script>
    <script src="LogoutButton.js"></script>
    <script src="ProfessorProfileButton.js"></script>
    <script src="ProfViewCreateThesisPageButton.js"></script>
    <script src="ProfAssignThesisPageButton.js"></script>
    <script src="ProfViewListThesisPageButton.js"></script>
    <script src="ProfManageThesisPageButton.js"></script>
    <script src="ProfRequests3.js"></script>
    <script src="ProfStatistics.js"></script>
</body>
</html>