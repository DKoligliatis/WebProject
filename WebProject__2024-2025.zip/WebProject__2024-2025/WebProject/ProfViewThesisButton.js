document.getElementById("view-thesis").addEventListener("click", function() {
    window.location.href = 'ProfViewThesisPage.php';
});