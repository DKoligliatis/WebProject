<?php

// Διαπιστευτήρια για τη βάση δεδομένων
$servername = "localhost";
$username = "root";
$password = "12345";
$database = "db";

$conn = new mysqli($servername, $username, $password, $database);

// Έλεγχος σύνδεσης
if ($conn->connect_error) {
    die("Σφάλμα σύνδεσης: " . $conn->connect_error);
}

?>
