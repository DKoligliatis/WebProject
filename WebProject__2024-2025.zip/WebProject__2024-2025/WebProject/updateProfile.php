<?php
// Σύνδεση με τη βάση δεδομένων και εκκίνηση συνεδρίας χρήστη
require 'config.php';  // Εισάγει το αρχείο με τις ρυθμίσεις σύνδεσης στη βάση
session_start();  // Ξεκινά την συνεδρία για να διαχειριστεί τα δεδομένα του χρήστη

// Έλεγχος αν ο χρήστης είναι συνδεδεμένος και έχει τον κατάλληλο τύπο χρήστη (πτυχιακός)
if (!isset($_SESSION['userID']) || $_SESSION['userType'] !== 'undergraduate') {
    http_response_code(401);  // Ορίζει κωδικό κατάστασης HTTP για μη εξουσιοδοτημένη πρόσβαση
    echo json_encode(['error' => 'Unauthorized']);  // Επιστρέφει μήνυμα λάθους σε μορφή JSON
    exit();  // Τερματίζει την εκτέλεση του κώδικα αν η πρόσβαση είναι μη εξουσιοδοτημένη
}

// Ανάθεση μεταβλητών με τα δεδομένα του χρήστη από την συνεδρία και τη φόρμα
$studentID = $_SESSION['userID'];  // Ανακτά το ID του φοιτητή από τη συνεδρία
$email = $_POST['email'] ?? null;  // Ελέγχει αν υπάρχει email στη φόρμα
$address = $_POST['address'] ?? null;  // Ελέγχει αν υπάρχει διεύθυνση στη φόρμα
$phone_mobile = $_POST['phone_mobile'] ?? null;  // Ελέγχει αν υπάρχει κινητό τηλέφωνο στη φόρμα
$phone_home = $_POST['phone_home'] ?? null;  // Ελέγχει αν υπάρχει σταθερό τηλέφωνο στη φόρμα

// Αν το email δεν έχει σταλεί, επιστρέφει μήνυμα λάθους
if (!$email) {
    echo json_encode(['error' => 'Το email είναι απαραίτητο.']);  // Μήνυμα λάθους σε μορφή JSON
    exit();  // Τερματίζει την εκτέλεση αν το email δεν είναι έγκυρο
}

try {
    // Δημιουργία SQL ερωτήματος για την ενημέρωση των προσωπικών στοιχείων του χρήστη
    $sql = "
        UPDATE undergraduates u
        JOIN users us ON u.studentID = us.userID
        SET us.acEmail = ?, u.address = ?, u.phone_mobile = ?, u.phone_home = ?
        WHERE u.studentID = ?
    ";

    // Προετοιμασία της SQL εντολής για εκτέλεση
    $stmt = $conn->prepare($sql);
    // Δέσμευση των παραμέτρων στην SQL εντολή
    $stmt->bind_param("sssii", $email, $address, $phone_mobile, $phone_home, $studentID);
    // Εκτέλεση της εντολής
    $stmt->execute();

    // Έλεγχος αν επηρεάστηκαν εγγραφές (αν δηλαδή έγινε ενημέρωση)
    if ($stmt->affected_rows > 0) {
        // Ενημέρωση των δεδομένων στη συνεδρία χρήστη
        $_SESSION['acEmail'] = $email;
        $_SESSION['address'] = $address;
        $_SESSION['phone_mobile'] = $phone_mobile;
        $_SESSION['phone_home'] = $phone_home;

        // Επιστροφή επιτυχίας σε μορφή JSON
        echo json_encode(['success' => true]);
    } else {
        // Επιστροφή μηνύματος λάθους αν δεν έγιναν αλλαγές
        echo json_encode(['error' => 'Δεν έγιναν αλλαγές.']);
    }

    // Κλείσιμο του statement και της σύνδεσης με τη βάση δεδομένων
    $stmt->close();
    $conn->close();
} catch (Exception $e) {
    // Επιστροφή μηνύματος λάθους σε περίπτωση σφάλματος
    echo json_encode(['error' => 'Σφάλμα διακομιστή: ' . $e->getMessage()]);
}
?>