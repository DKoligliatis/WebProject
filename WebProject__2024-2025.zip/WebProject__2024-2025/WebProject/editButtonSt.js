document.getElementById("edit-buttonSt").addEventListener("click", function() {
    window.location.href = 'updatePageSt.php';
});