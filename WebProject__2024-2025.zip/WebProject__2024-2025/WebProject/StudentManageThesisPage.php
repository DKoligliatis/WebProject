<?php
require 'config.php';
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'];
    $studentID = $_SESSION['userID'];

    if ($action === 'getProfessors') {
        // Επιστροφή λίστας καθηγητών
        $sql = "SELECT profID, CONCAT(firstName, ' ', lastName) AS fullName 
                FROM professors JOIN users ON professors.profID = users.userID 
                WHERE profID NOT IN (SELECT profsupervID FROM topics WHERE topicID IN (SELECT topicID FROM diplomas WHERE studentID = $studentID))";
       
       $result = $conn->query($sql);

        if (!$result) {
            die("Database query failed: " . $conn->error);
        }

        $professors = [];
        while ($row = $result->fetch_assoc()) {
            $professors[] = $row;
        }

        echo json_encode($professors);
        exit();
    }

    if ($action === 'sendInvitation') {
        // Αποστολή αίτησης μέσω της `sendInvitation`
        $studentID = $_SESSION['userID'];
        $professorID = $_POST['professorID'];

        try {
            $stmt = $conn->prepare("CALL sendInvitation(?, ?)");
            $stmt->bind_param("ii", $studentID, $professorID);
            $stmt->execute();
            echo json_encode(['success' => true, 'message' => 'Η αίτηση στάλθηκε επιτυχώς.']);
        } catch (Exception $e) {
            echo json_encode(['success' => false, 'message' => $e->getMessage()]);
        }
        exit();
    }

    if ($action === 'getDiplomaStatus') {
        // Ανάκτηση κατάστασης διπλωματικής
        $sql = "SELECT d.status 
                FROM diplomas d
                WHERE d.studentID = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $studentID);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $diploma = $result->fetch_assoc();
            echo json_encode(['success' => true, 'status' => $diploma['status']]);
        } else {
            echo json_encode(['success' => false, 'message' => 'Δεν σας έχει ανατεθεί κάποια διπλωματική.']);
        }
        exit();
    }

    if ($action === 'setExamDetails') {
        // Καταχώρηση λεπτομερειών εξέτασης
        $examWay = $_POST['examWay'];
        $examDate = $_POST['examDate'];
        $examTime = $_POST['examTime'];
        $examLocation = $_POST['examLocation'];

        $stmt = $conn->prepare("UPDATE diplomas SET examWay = ?, examDate = ?, examTime = ?, examLocation = ? WHERE studentID = ?");
        $stmt->bind_param("sssi", $examDate, $examTime, $examLocation, $studentID);
        if ($stmt->execute()) {
            echo json_encode(['success' => true, 'message' => 'Τα στοιχεία εξέτασης ενημερώθηκαν.']);
        } else {
            echo json_encode(['success' => false, 'message' => 'Αποτυχία κατά την καταχώρηση των στοιχείων εξέτασης.']);
        }
        exit();
    }
    if ($action === 'uploadToNhmerths'){
        $nhmerthsLink = $_POST['nhmerthsLink'];
        $studentID = $_SESSION['userID'];
        $stmt = $conn->prepare("UPDATE diplomas SET nhmerthsLink = ? WHERE studentID = ?");
        $stmt->bind_param("si", $nhmerthsLink, $studentID);
        
        if ($stmt->execute()) {
            echo json_encode(['success' => true, 'message' => 'Ο σύνδεσμος για τον Νημερτή εισάχθηκε επιτυχώς.']);
        } else {
            echo json_encode(['success' => false, 'message' => 'Υπήρξε σφάλαμα κατά την προσθήλη συνδέσμου για τον Νημερτή.']);
        }
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="el">
<head>
    <!-- Τίτλος της σελίδας -->
    <title>ΤΜΥΠ | Διαχείριση Διπλωματικής Εργασίας</title>
    
    <!-- Εικόνα που εμφανίζεται στην καρτέλα -->
    <link rel="icon" type="image/png" href="ceid_logo.png">
    
    <!-- Σύνδεση με το αρχείο CSS -->
    <link rel="stylesheet" href="StudentManageThesisPage.css">
</head>
<body>

    <!-- Άνω τμήμα της σελίδας -->
    <div class="upper-section">
        <a href="https://www.ceid.upatras.gr" target="_self">
            <img src="upatras_ceid_logo.png" alt="upatras_ceid_logo">
        </a>
        <button class="logout-button" id="logout-button" onclick="window.location.href='logout.php'">Έξοδος</button>
    </div>

    <div class="container">
        <div class="main-menu">
            <button class="menu-item" id="profile" onclick="window.location.href='StudentProfilePage.php'">Προφίλ</button>
            <button class="menu-item" id="view-thesis" onclick="window.location.href='StudentViewThesis.php'">Προβολή Θέματος<br>Διπλωματικής Εργασίας</button>
            <button class="menu-item" id="manage-thesis" onclick="window.location.href='StudentManageThesisPage.php'">Διαχείριση Διπλωματικής<br>Εργασίας</button>
        </div>
    </div>

    <div class="content">
        <h2>Διαχείριση Διπλωματικής Εργασίας</h2>
        <div id="dynamic-content">
            <p>Φόρτωση...</p>
        </div>
    </div>

    <script>
        function loadDynamicContent() {
            fetch('StudentManageThesisPage.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: 'action=getDiplomaStatus'
            })
            .then(response => response.json())
            .then(data => {
                const contentDiv = document.getElementById('dynamic-content');

                if (data.success) {
                    const status = data.status;
                    let html = '';

                    if (status === 'Temporarily Assigned') {
                        // Υπό Ανάθεση
                        html = `
                            <h3>Επιλέξτε Μέλη Τριμελούς Επιτροπής</h3>
                            <form id="send-invitation-form">
                                <label for="professor-select">Επιλέξτε Καθηγητή:</label>
                                <select id="professor-select"></select>
                                <button type="submit">Αποστολή</button>
                            </form>
                        `;
                        loadProfessors();

                    } else if (status === 'Under Review') {
                        // Υπό Εξέταση
                        html = `
                            <h3>Ανάρτηση Προσωρινού Αρχείου Διπλωματικής</h3>
                            <form action="uploadTempDip.php" method="POST" enctype="multipart/form-data">
                                <label for="pdf_file">Επιλογή Αρχείου:</label><br>
                                <input type="file" id="pdf_file" name="pdf_file" accept=".pdf" required><br><br>
                                <input type="submit" value="Ανέβασμα Προσωρινής Διπλωματικής">
                            </form>
                            <br>
                            <h3>Καταχώρηση Στοιχείων Εξέτασης</h3>
                            <form id="exam-form" action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
                            <input type="hidden" name="action" value="setExamDetails"> <!-- Hidden input for action -->
                                <table>
                                <tr>
                                    <td><label for="examWay">Τρόπος Εξέτασης:</label></td>
                                    <td><input type="text" id="examWay" name="examWay" required></td>
                                </tr>
                                <tr>
                                    <td><label for="examDate">Ημερομηνία:</label></td>
                                    <td><input type="date" id="examDate" name="examDate" required></td>
                                </tr>
                                <tr>
                                    <td><label for="examTime">Ώρα:</label></td>
                                    <td><input type="time" id="examTime" name="examTime" required></td>
                                </tr>
                                <tr>
                                    <td><label for="examLocation">Τοποθεσία/Σύνδεσμος:</label></td>
                                    <td><input type="text" id="examLocation" name="examLocation" required></td>
                                </tr>
                                <tr>
                                    <td colspan="2" style="text-align: center;">
                                    <br>
                                    <button type="submit">Καταχώρηση</button>
                                    </td>
                                </tr>
                                </table>
                            </form>
<h3>Νημερτής</h3>
<form id="nhmerth-form" action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
<input type="hidden" name="action" value="uploadToNhmerths"> <!-- Hidden input for action -->
    <table> 
        <tr>
            <td><label for="nhmerthsLink">Σύνδεσμος:</label></td>
            <td><input type="text" id="nhmerthsLink" name="nhmerthsLink" required></td>
        </tr>
        <tr>
            <td colspan="2" style="text-align: center;">
                <br>
                <button type="submit">Καταχώρηση</button>
            </td>
        </tr>
    <table>
</form>`;
                    } else if (status === 'Completed') {
                        // Περατωμένη
                        html = `
                            <h2>Πληροφορίες Διπλωματικής</h2>
                            <p>Η διπλωματική σας έχει περατωθεί. Δείτε το τελικό αρχείο και την αξιολόγηση από την επιτροπή.</p>
                        `;
                    } else {
                        html = '<p>Δεν βρέθηκαν σχετικές πληροφορίες για την κατάσταση της διπλωματικής σας.</p>';
                    }

                    contentDiv.innerHTML = html;

                    // Add event listeners for forms
                    addEventListeners();
                } else {
                    contentDiv.innerHTML = `<p>${data.message}</p>`;
                }
            });
        }

        function loadProfessors() {
            fetch('StudentManageThesisPage.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: 'action=getProfessors'
            })
            .then(response => response.json())
            .then(data => {
                const professorSelect = document.getElementById('professor-select');
                professorSelect.innerHTML = '<option value="">Επιλέξτε Καθηγητή</option>';
                data.forEach(professor => {
                    const option = document.createElement('option');
                    option.value = professor.profID;
                    option.textContent = professor.fullName;
                    professorSelect.appendChild(option);
                });
            });
        }

        function addEventListeners() {
            const sendForm = document.getElementById('send-invitation-form');
            if (sendForm) {
                sendForm.addEventListener('submit', event => {
                    event.preventDefault();
                    const professorID = document.getElementById('professor-select').value;

                    if (!professorID) {
                        alert('Παρακαλώ επιλέξτε καθηγητή πριν αποστείλετε την αίτηση.');
                        return;
                    }

                    fetch('StudentManageThesisPage.php', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                        body: `action=sendInvitation&professorID=${professorID}`
                    })
                    .then(response => response.json())
                    .then(data => {
                        alert(data.success ? data.message : `Σφάλμα: ${data.message}`);
                    })
                    .catch(error => {
                        console.error('Error sending invitation:', error);
                        alert('Παρουσιάστηκε πρόβλημα κατά την αποστολή της αίτησης.');
                    });
                });
            }

            
function addEventListeners() {
const examForm = document.getElementById('exam-form');
if (examForm) {
examForm.addEventListener('submit', function(event) {
event.preventDefault(); // Prevent the form from submitting traditionally


// Get the form data
const examWay = document.getElementById('examWay').value;
const examDate = document.getElementById('examDate').value;
const examTime = document.getElementById('examTime').value;
const examLocation = document.getElementById('examLocation').value;

// Log data to console for debugging (optional)
console.log({
    examWay, examDate, examTime, examLocation
});

// Send the data using fetch
fetch('StudentManageThesisPage.php', {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: `action=setExamDetails&examWay=${examWay}&examDate=${examDate}&examTime=${examTime}&examLocation=${examLocation}`
})
.then(response => response.json())
.then(data => {
    alert(data.message); // Show the success or error message
})
.catch(error => {
    console.error('Error:', error);
    alert('Παρουσιάστηκε πρόβλημα κατά την καταχώρηση των στοιχείων εξέτασης.');
});
});
    }
}  
}

const nhmerthsForm = document.getElementById('nhmerth-form');
if (nhmerthsForm) {
    nhmerthsForm.addEventListener('submit', function(event) {
        event.preventDefault(); // Prevent traditional form submission

        // Get the Νημερτής link from the input
        const nhmerthsLink = document.getElementById('nhmerthsLink').value;

        // Send the data to the backend
        fetch('StudentManageThesisPage.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: `action=uploadToNhmerths&nhmerthsLink=${encodeURIComponent(nhmerthsLink)}`
        })
        .then(response => response.json())
        .then(data => {
            alert(data.message); // Show the server response
        })
        .catch(error => {
            console.error('Error:', error);
            alert('Παρουσιάστηκε πρόβλημα κατά την καταχώρηση του συνδέσμου Νημερτής.');
        });
    });
}


        window.onload = loadDynamicContent;

        window.onload = loadDynamicContent;
    </script>
</body>
</html>