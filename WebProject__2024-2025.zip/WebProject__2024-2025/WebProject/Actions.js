document.querySelector('.login-button').addEventListener('click', function() {
    // Change the current location to the new HTML page
    window.location.href = 'LoginPage.php';  // This will load 'newPage.html' in the same tab
});