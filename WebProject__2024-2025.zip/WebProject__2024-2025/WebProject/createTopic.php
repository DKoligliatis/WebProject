<?php
require 'config.php';
session_start();

$response = []; // Array to hold response

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $profSupervID = $_SESSION['userID'];
    $title = $_POST['title'];
    $description = $_POST['description'];
    $file = $_FILES['pdf_file'];

    try {
        $filePath = null;

        if (isset($file) && $file['error'] == 0) {
            $fileTmpName = $file['tmp_name'];
            $filePath = file_get_contents($fileTmpName);
        }

        $stmt = $conn->prepare("CALL createTopic(?, ?, ?, ?)");
        $stmt->bind_param("ssss", $title, $description, $filePath, $profSupervID);

        if ($stmt->execute()) {
            $response = ["status" => "success", "message" => "΄Επιτυχής Διημιουργία Διπλωματικής!"];
        } else {
            $response = ["status" => "error", "message" => "Σφάλμα κατά την δημιουργία Διπλωματικής: " . $stmt->error];
        }

        $stmt->close();
    } catch (Exception $e) {
        $response = ["status" => "error", "message" => "An unexpected error occurred: " . $e->getMessage()];
    }
}

$conn->close();
header('Content-Type: application/json');
echo json_encode($response);
?>