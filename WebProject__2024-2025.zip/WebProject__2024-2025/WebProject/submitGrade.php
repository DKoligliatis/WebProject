<?php
require 'config.php'; // Database connection
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $professorID = intval($_POST['profID']);
    $committeeID = intval($_POST['committeeID']);
    $grade = floatval($_POST['grade']);

    // Validate session
    if (!isset($_SESSION['userID']) || $_SESSION['userID'] !== $professorID) {
        echo "<script>alert('Unauthorized action.');</script>";
        exit;
    }

    // Validate grade range
    if ($grade < 1 || $grade > 10) {
        echo "<script>alert('Invalid grade. Must be between 1 and 10.');</script>";
        exit;
    }

    // Check the gradelog table for existing records
    $checkQuery = "SELECT COUNT(*) AS gradeCount FROM gradelog WHERE committeeID = ?";
    $checkStmt = $conn->prepare($checkQuery);

    $checkStmt->bind_param("i", $committeeID);

    if (!$checkStmt) {
        error_log("Database error: " . $conn->error);
        echo "<script>alert('Internal server error.');</script>";
        exit;
    }
    $checkStmt->execute();
    $result = $checkStmt->get_result();
    $row = $result->fetch_assoc();
    $checkStmt->close();

    if ($row['gradeCount'] >= 3) {
        // Return error message
        echo "<script>alert('Έχετε ήδη προσθέσει βαθμό.');</script>";
        exit;
    }

    // Prepare the query to insert the grade
    $query = "CALL insertGradeIfUnderReview(?, ?, ?)";
    $stmt = $conn->prepare($query);
    if (!$stmt) {
        error_log("Database error: " . $conn->error);
        echo "<script>alert('Internal server error.');</script>";
        exit;
    }

    $stmt->bind_param("iid", $professorID, $committeeID, $grade);

    header("Location: ProfManageThesisPage.php");
    
    if ($stmt->execute()) {
        echo "<script>alert('Επιτυχής προσθήκη βαθμολογίας.');</script>";
    } else {
        // Return error message
        echo "<script>alert('Σφάλμα κατά την εισαγωγή βαθμού: " . $stmt->error . "');</script>";
    }
    
} else {
    echo "<script>alert('Invalid request method.');</script>";
}
?>